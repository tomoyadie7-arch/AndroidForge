# Add project specific ProGuard rules here.
-keep class com.signalprivate.model.** { *; }
-keep class com.signalprivate.database.** { *; }
