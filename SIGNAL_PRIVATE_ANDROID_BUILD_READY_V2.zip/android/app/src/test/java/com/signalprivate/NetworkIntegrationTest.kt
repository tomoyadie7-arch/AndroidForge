package com.signalprivate

import com.signalprivate.model.*
import com.signalprivate.network.PacketSerializer
import com.signalprivate.security.CryptoEngine
import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

class NetworkIntegrationTest {

    @Test
    fun testDirectMessageAndDeliveryAckPipeline() {
        // Generate cryptographic identities for Node A and Node B
        val nodeAKeys = CryptoEngine.generateKeyPair()
        val nodeBKeys = CryptoEngine.generateKeyPair()

        val nodeADeviceId = "DEVICE-NICK"
        val nodeBDeviceId = "DEVICE-OLIVER"

        // Derive shared secret key
        val secretKeyA = CryptoEngine.deriveSharedSecret(nodeAKeys.private, nodeBKeys.public)
        val secretKeyB = CryptoEngine.deriveSharedSecret(nodeBKeys.private, nodeAKeys.public)

        // Node A creates message
        val plaintext = "Dinner is ready. Come downstairs."
        val encrypted = CryptoEngine.encrypt(plaintext, secretKeyA)

        val messagePayload = MessagePayload(
            messageId = "msg_1001",
            conversationId = "conv_oliver",
            senderDeviceId = nodeADeviceId,
            receiverDeviceId = nodeBDeviceId,
            encryptedBody = encrypted.ciphertextBase64,
            ivBase64 = encrypted.ivBase64,
            timestamp = 1700000000L
        )

        val wirePacket = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.MESSAGE,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = nodeADeviceId,
            receiverDeviceId = nodeBDeviceId,
            payloadJson = PacketSerializer.serializeMessagePayload(messagePayload)
        )
        val signedWirePacket = PacketSerializer.signPacket(wirePacket, nodeAKeys.private)

        // Node B receives and verifies signature
        assertTrue(PacketSerializer.verifyPacketSignature(signedWirePacket, nodeAKeys.public))

        // Node B decrypts body
        val receivedPayload = PacketSerializer.deserializeMessagePayload(signedWirePacket.payloadJson)
        val decryptedBody = CryptoEngine.decrypt(
            com.signalprivate.security.EncryptedPayload(receivedPayload.encryptedBody, receivedPayload.ivBase64),
            secretKeyB
        )
        assertEquals(plaintext, decryptedBody)

        // Node B creates MESSAGE_ACK
        val ackPayload = MessageAckPayload(
            messageId = receivedPayload.messageId,
            receiverDeviceId = nodeBDeviceId,
            deliveredTimestamp = 1700000050L
        )
        val ackPacket = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.MESSAGE_ACK,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = nodeBDeviceId,
            receiverDeviceId = nodeADeviceId,
            payloadJson = PacketSerializer.serializeMessageAck(ackPayload)
        )
        val signedAck = PacketSerializer.signPacket(ackPacket, nodeBKeys.private)

        // Node A receives and verifies ACK
        assertTrue(PacketSerializer.verifyPacketSignature(signedAck, nodeBKeys.public))
        val deserializedAck = PacketSerializer.deserializeMessageAck(signedAck.payloadJson)
        assertEquals("msg_1001", deserializedAck.messageId)
    }
}
