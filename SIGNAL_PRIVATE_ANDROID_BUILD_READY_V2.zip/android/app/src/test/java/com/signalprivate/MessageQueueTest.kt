package com.signalprivate

import com.signalprivate.model.Message
import com.signalprivate.model.MessageStatus
import org.junit.Assert.*
import org.junit.Test

class MessageQueueTest {

    @Test
    fun testMessageStatusTransitions() {
        val originalMsg = Message(
            messageId = "msg_001",
            conversationId = "conv_oliver",
            senderDeviceId = "DEVICE_NICK",
            receiverDeviceId = "DEVICE_OLIVER",
            body = "Hello Oliver",
            createdAt = 1000L,
            status = MessageStatus.QUEUED
        )

        assertEquals(MessageStatus.QUEUED, originalMsg.status)

        // Peer discovered -> SENDING
        val sendingMsg = originalMsg.copy(status = MessageStatus.SENDING)
        assertEquals(MessageStatus.SENDING, sendingMsg.status)

        // Transport completed -> SENT
        val sentMsg = sendingMsg.copy(status = MessageStatus.SENT)
        assertEquals(MessageStatus.SENT, sentMsg.status)

        // Remote ACK received -> DELIVERED
        val deliveredMsg = sentMsg.copy(status = MessageStatus.DELIVERED, deliveryTimestamp = 1050L)
        assertEquals(MessageStatus.DELIVERED, deliveredMsg.status)
        assertNotNull(deliveredMsg.deliveryTimestamp)

        // Recipient opened conversation -> READ
        val readMsg = deliveredMsg.copy(status = MessageStatus.READ, readTimestamp = 1100L)
        assertEquals(MessageStatus.READ, readMsg.status)
        assertNotNull(readMsg.readTimestamp)
    }

    @Test
    fun testMessageOrdering() {
        val msg1 = Message("id1", "conv1", "devA", "devB", "One", 1000L, MessageStatus.DELIVERED)
        val msg2 = Message("id2", "conv1", "devA", "devB", "Two", 1020L, MessageStatus.DELIVERED)
        val msg3 = Message("id3", "conv1", "devA", "devB", "Three", 1050L, MessageStatus.DELIVERED)

        val list = listOf(msg3, msg1, msg2)
        val sorted = list.sortedBy { it.createdAt }

        assertEquals("id1", sorted[0].messageId)
        assertEquals("id2", sorted[1].messageId)
        assertEquals("id3", sorted[2].messageId)
    }

    @Test
    fun testDuplicateMessagePreventionByIdempotency() {
        val set = mutableSetOf<String>()
        val msgId = "unique_uuid_42"

        val firstAdd = set.add(msgId)
        assertTrue("First insert must succeed", firstAdd)

        val secondAdd = set.add(msgId)
        assertFalse("Duplicate messageId must be rejected", secondAdd)
    }
}
