package com.signalprivate

import com.signalprivate.security.CryptoEngine
import org.junit.Assert.*
import org.junit.Test

class CryptoEngineTest {

    @Test
    fun testKeyPairGenerationAndSignatureVerification() {
        val keyPair = CryptoEngine.generateKeyPair()
        assertNotNull(keyPair.public)
        assertNotNull(keyPair.private)

        val data = "SIGNAL_TEST_PAYLOAD_12345".toByteArray(Charsets.UTF_8)
        val signature = CryptoEngine.sign(data, keyPair.private)
        assertNotNull(signature)
        assertTrue(signature.isNotEmpty())

        val isValid = CryptoEngine.verify(data, signature, keyPair.public)
        assertTrue("Signature should verify against matching public key", isValid)

        // Verify with altered data
        val alteredData = "SIGNAL_ALTERED_PAYLOAD_99999".toByteArray(Charsets.UTF_8)
        val isTamperedValid = CryptoEngine.verify(alteredData, signature, keyPair.public)
        assertFalse("Tampered signature should fail verification", isTamperedValid)
    }

    @Test
    fun testPairwiseECDHAndAESGCMEncryption() {
        // Device A (Nick) & Device B (Oliver)
        val deviceA = CryptoEngine.generateKeyPair()
        val deviceB = CryptoEngine.generateKeyPair()

        // Derive shared secret symmetrically
        val sharedSecretA = CryptoEngine.deriveSharedSecret(deviceA.private, deviceB.public)
        val sharedSecretB = CryptoEngine.deriveSharedSecret(deviceB.private, deviceA.public)

        assertArrayEquals("Derived secrets must match on both ends", sharedSecretA.encoded, sharedSecretB.encoded)

        val originalPlaintext = "Are you home? The power is out on 5th Ave."
        val encryptedPayload = CryptoEngine.encrypt(originalPlaintext, sharedSecretA)

        assertNotEquals(originalPlaintext, encryptedPayload.ciphertextBase64)
        assertNotNull(encryptedPayload.ivBase64)

        // Device B decrypts with its derived key
        val decryptedPlaintext = CryptoEngine.decrypt(encryptedPayload, sharedSecretB)
        assertEquals("Decrypted plaintext must match original", originalPlaintext, decryptedPlaintext)
    }

    @Test
    fun testInvitationCodeFormat() {
        val code = CryptoEngine.generateInvitationCode()
        assertNotNull(code)
        // Format: XXX-XXX-XXX (11 characters with hyphens)
        assertEquals(11, code.length)
        assertTrue("Matches pattern", code.matches(Regex("^[2-9A-HJ-NP-Z]{3}-[2-9A-HJ-NP-Z]{3}-[2-9A-HJ-NP-Z]{3}$")))
    }
}
