package com.signalprivate

import com.signalprivate.model.*
import com.signalprivate.network.PacketSerializer
import com.signalprivate.security.CryptoEngine
import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

class SyncEngineTest {

    @Test
    fun testTwoWaySynchronizationDeltaCalculation() {
        // Device A has messages 1, 2, 3, 4
        val phoneAMessages = listOf("msg_1", "msg_2", "msg_3", "msg_4")
        // Device B has messages 1, 2, 3, 5, 6
        val phoneBMessages = listOf("msg_1", "msg_2", "msg_3", "msg_5", "msg_6")

        // Phone A sends SYNC_REQUEST with known IDs to Phone B
        val knownByA = phoneAMessages.toSet()
        val missingOnA = phoneBMessages.filter { it !in knownByA }

        assertEquals(listOf("msg_5", "msg_6"), missingOnA)

        // Phone B sends SYNC_REQUEST with known IDs to Phone A
        val knownByB = phoneBMessages.toSet()
        val missingOnB = phoneAMessages.filter { it !in knownByB }

        assertEquals(listOf("msg_4"), missingOnB)

        // After delta exchange:
        val combinedA = (phoneAMessages + missingOnA).sorted()
        val combinedB = (phoneBMessages + missingOnB).sorted()

        assertEquals("Both phones must reach identical synchronized state", combinedA, combinedB)
        assertEquals(listOf("msg_1", "msg_2", "msg_3", "msg_4", "msg_5", "msg_6"), combinedA)
    }

    @Test
    fun testPacketSerializationAndSignature() {
        val keyPair = CryptoEngine.generateKeyPair()
        val originalPacket = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.MESSAGE,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = "DEVICE_NICK",
            receiverDeviceId = "DEVICE_OLIVER",
            timestamp = 1700000000L,
            payloadJson = "{\"body\":\"test\"}"
        )

        val signedPacket = PacketSerializer.signPacket(originalPacket, keyPair.private)
        assertTrue(signedPacket.signatureBase64.isNotEmpty())

        val isValid = PacketSerializer.verifyPacketSignature(signedPacket, keyPair.public)
        assertTrue("Packet signature must verify with public key", isValid)

        // Serialize to JSON string and back
        val json = PacketSerializer.serializePacket(signedPacket)
        val deserialized = PacketSerializer.deserializePacket(json)

        assertEquals(originalPacket.packetId, deserialized.packetId)
        assertEquals(originalPacket.packetType, deserialized.packetType)
        assertEquals(originalPacket.senderDeviceId, deserialized.senderDeviceId)
        assertEquals(signedPacket.signatureBase64, deserialized.signatureBase64)

        val isValidAfterWire = PacketSerializer.verifyPacketSignature(deserialized, keyPair.public)
        assertTrue("Deserialized wire packet must retain valid signature", isValidAfterWire)
    }
}
