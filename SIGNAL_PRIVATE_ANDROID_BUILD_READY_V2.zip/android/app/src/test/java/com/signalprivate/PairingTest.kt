package com.signalprivate

import com.signalprivate.model.PairingRequest
import com.signalprivate.model.PairingStatus
import com.signalprivate.model.TrustState
import org.junit.Assert.*
import org.junit.Test

class PairingTest {

    @Test
    fun testPairingExpiration() {
        val now = 1000000L
        val activeRequest = PairingRequest(
            requestId = "req_1",
            temporaryCode = "K7F-29Q-81M",
            requesterDeviceId = "DEVICE-OLIVER",
            requesterName = "OLIVER",
            requesterPublicKey = "dummyPubBase64",
            createdAt = now,
            expiresAt = now + 10 * 60 * 1000L // +10 min
        )

        assertFalse("Request should not be expired during validity window", activeRequest.isExpired)

        val expiredRequest = activeRequest.copy(expiresAt = now - 1000L)
        assertTrue("Request with past expiresAt must be considered expired", expiredRequest.isExpired)
    }

    @Test
    fun testRevokedDeviceRejection() {
        val trustedDeviceState = TrustState.TRUSTED
        val revokedDeviceState = TrustState.REVOKED

        fun canAcceptMessage(state: TrustState): Boolean {
            return state == TrustState.TRUSTED
        }

        assertTrue("Trusted device messages accepted", canAcceptMessage(trustedDeviceState))
        assertFalse("Revoked device messages rejected", canAcceptMessage(revokedDeviceState))
        assertFalse("Pending device messages rejected", canAcceptMessage(TrustState.PENDING))
    }

    @Test
    fun testApprovalStateTransitions() {
        val req = PairingRequest(
            requestId = "req_2",
            temporaryCode = "ABC-DEF-GHI",
            requesterDeviceId = "DEVICE-DAD",
            requesterName = "DAD",
            requesterPublicKey = "dummyPubBase64"
        )
        assertEquals(PairingStatus.ACTIVE, req.status)

        val approved = req.copy(status = PairingStatus.APPROVED)
        assertEquals(PairingStatus.APPROVED, approved.status)

        val rejected = req.copy(status = PairingStatus.REJECTED)
        assertEquals(PairingStatus.REJECTED, rejected.status)
    }
}
