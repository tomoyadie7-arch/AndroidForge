package com.signalprivate.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprivate.model.InternetConnectivity
import com.signalprivate.model.LocalNetworkConnectivity
import com.signalprivate.model.SignalMeshStatus
import com.signalprivate.ui.theme.*
import com.signalprivate.ui.viewmodel.SignalViewModel

@Composable
fun HomeScreen(
    viewModel: SignalViewModel,
    onNavigateToChat: (String) -> Unit,
    onNavigateToMembers: () -> Unit,
    onNavigateToDevices: () -> Unit,
    onNavigateToNetworkStatus: () -> Unit
) {
    val diagnostics by viewModel.networkDiagnostics.collectAsState()
    val members by viewModel.trustedMembers.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()
    val pendingRequests by viewModel.pendingPairingRequests.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SignalDarkBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // App Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SIGNAL // PRIVATE",
                    style = MaterialTheme.typography.headlineLarge,
                    color = SignalTextPrimary
                )
                Text(
                    text = "LOCAL MESH • ZERO CLOUD",
                    style = MaterialTheme.typography.labelSmall,
                    color = SignalCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // NETWORK Section
        Text(
            text = "NETWORK",
            style = MaterialTheme.typography.labelSmall,
            color = SignalTextSecondary
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // INTERNET Status Box
            NetworkStatusBox(
                title = "INTERNET",
                value = if (diagnostics.internet == InternetConnectivity.ONLINE) "ONLINE" else "OFFLINE",
                isActive = diagnostics.internet == InternetConnectivity.ONLINE,
                activeColor = SignalIce,
                inactiveColor = SignalAmber,
                modifier = Modifier.weight(1f)
            )

            // LOCAL NETWORK Status Box
            NetworkStatusBox(
                title = "LOCAL NETWORK",
                value = if (diagnostics.localNetwork == LocalNetworkConnectivity.CONNECTED) "CONNECTED" else "DISCONNECTED",
                isActive = diagnostics.localNetwork == LocalNetworkConnectivity.CONNECTED,
                activeColor = SignalIce,
                inactiveColor = SignalRed,
                modifier = Modifier.weight(1.2f)
            )

            // SIGNAL Status Box
            NetworkStatusBox(
                title = "SIGNAL",
                value = if (diagnostics.signal == SignalMeshStatus.ONLINE) "ONLINE" else "OFFLINE",
                isActive = diagnostics.signal == SignalMeshStatus.ONLINE,
                activeColor = SignalCyan,
                inactiveColor = SignalTextMuted,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // OWNER Section
        Text(
            text = "OWNER",
            style = MaterialTheme.typography.labelSmall,
            color = SignalTextSecondary
        )
        Spacer(modifier = Modifier.height(6.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = viewModel.identityManager.displayName.uppercase(),
                        style = MaterialTheme.typography.headlineMedium,
                        color = SignalTextPrimary
                    )
                    Text(
                        text = "ID: ${viewModel.identityManager.deviceId}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalTextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = SignalSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SignalCyan.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = if (viewModel.identityManager.isOwner) "CONTROLLER" else "NODE",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalCyan
                    )
                }
            }
        }

        // Pending Pairing Requests Banner (if any)
        if (pendingRequests.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToMembers() },
                shape = RoundedCornerShape(8.dp),
                color = SignalAmber.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, SignalAmber)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "NEW PAIRING REQUEST",
                            style = MaterialTheme.typography.titleMedium,
                            color = SignalAmber
                        )
                        Text(
                            text = "${pendingRequests.first().requesterName} wants to pair",
                            style = MaterialTheme.typography.bodySmall,
                            color = SignalTextPrimary
                        )
                    }
                    Text(
                        text = "REVIEW →",
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalAmber,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // MEMBERS Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MEMBERS",
                style = MaterialTheme.typography.labelSmall,
                color = SignalTextSecondary
            )
            Text(
                text = if (diagnostics.isDiscoveryActive) "DISCOVERY ACTIVE" else "IDLE",
                style = MaterialTheme.typography.labelSmall,
                color = if (diagnostics.isDiscoveryActive) SignalIce else SignalTextMuted
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        val otherMembers = members.filter { it.deviceId != viewModel.identityManager.deviceId }

        if (otherMembers.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                shape = RoundedCornerShape(8.dp),
                color = SignalDarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "NO TRUSTED MEMBERS YET",
                        style = MaterialTheme.typography.titleMedium,
                        color = SignalTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Add family and close members via private 10-minute pairing codes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalTextMuted,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(otherMembers) { member ->
                    val isOnline = discoveredPeers.containsKey(member.deviceId)
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToChat(member.deviceId) },
                        shape = RoundedCornerShape(8.dp),
                        color = SignalDarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (isOnline) SignalIce else SignalTextMuted)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = member.displayName.uppercase(),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = SignalTextPrimary
                                    )
                                    Text(
                                        text = if (isOnline) "● LOCAL CONNECTION" else "LOCAL PEER OFFLINE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isOnline) SignalIce else SignalTextMuted
                                    )
                                }
                            }

                            Text(
                                text = "CHAT →",
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalCyan
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Action Buttons Row (OPEN CHAT, MANAGE MEMBERS, DEVICES, NETWORK STATUS)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val firstMember = otherMembers.firstOrNull()
                        if (firstMember != null) {
                            onNavigateToChat(firstMember.deviceId)
                        } else {
                            onNavigateToMembers()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SignalCyan, contentColor = SignalDarkBackground)
                ) {
                    Text("OPEN CHAT", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = onNavigateToMembers,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SignalSurfaceElevated, contentColor = SignalTextPrimary)
                ) {
                    Text("MANAGE MEMBERS", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onNavigateToDevices,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SignalTextSecondary)
                ) {
                    Text("DEVICES", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onNavigateToNetworkStatus,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SignalTextSecondary)
                ) {
                    Text("NETWORK STATUS", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun NetworkStatusBox(
    title: String,
    value: String,
    isActive: Boolean,
    activeColor: Color,
    inactiveColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = SignalDarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = SignalTextMuted,
                fontSize = 9.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = if (isActive) activeColor else inactiveColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
