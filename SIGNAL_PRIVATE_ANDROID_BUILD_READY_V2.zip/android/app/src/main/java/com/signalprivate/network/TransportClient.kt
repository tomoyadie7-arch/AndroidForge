package com.signalprivate.network

import android.util.Log
import com.signalprivate.model.ProtocolPacket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket

class TransportClient {
    companion object {
        private const val TAG = "SignalClient"
        private const val CONNECT_TIMEOUT_MS = 5000
        private const val READ_TIMEOUT_MS = 8000
    }

    /**
     * Sends a packet to peer host:port and waits for response packet.
     */
    suspend fun sendAndReceive(
        host: String,
        port: Int,
        packet: ProtocolPacket
    ): Result<ProtocolPacket> = withContext(Dispatchers.IO) {
        val socket = Socket()
        try {
            socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            socket.soTimeout = READ_TIMEOUT_MS

            val outputStream = DataOutputStream(socket.getOutputStream())
            val inputStream = DataInputStream(socket.getInputStream())

            val json = PacketSerializer.serializePacket(packet)
            val bytes = json.toByteArray(Charsets.UTF_8)

            outputStream.writeInt(bytes.size)
            outputStream.write(bytes)
            outputStream.flush()

            // Read response
            val respLength = inputStream.readInt()
            if (respLength <= 0 || respLength > 10 * 1024 * 1024) {
                return@withContext Result.failure(IllegalStateException("Invalid response packet size: $respLength"))
            }

            val respBuffer = ByteArray(respLength)
            inputStream.readFully(respBuffer)
            val respJson = String(respBuffer, Charsets.UTF_8)
            val responsePacket = PacketSerializer.deserializePacket(respJson)

            Result.success(responsePacket)
        } catch (e: Exception) {
            Log.w(TAG, "Failed communicating with $host:$port -> ${e.message}")
            Result.failure(e)
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    /**
     * Sends a packet without waiting for response (fire-and-forget or simplex).
     */
    suspend fun sendOneWay(
        host: String,
        port: Int,
        packet: ProtocolPacket
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val socket = Socket()
        try {
            socket.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            val outputStream = DataOutputStream(socket.getOutputStream())

            val json = PacketSerializer.serializePacket(packet)
            val bytes = json.toByteArray(Charsets.UTF_8)

            outputStream.writeInt(bytes.size)
            outputStream.write(bytes)
            outputStream.flush()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Failed sending one-way packet to $host:$port -> ${e.message}")
            Result.failure(e)
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }
}
