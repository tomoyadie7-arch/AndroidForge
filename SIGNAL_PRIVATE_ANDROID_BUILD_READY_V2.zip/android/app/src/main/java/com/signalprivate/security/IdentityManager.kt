package com.signalprivate.security

import android.content.Context
import android.content.SharedPreferences
import java.security.KeyPair
import java.security.PrivateKey
import java.security.PublicKey
import java.util.UUID

class IdentityManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "signal_identity_prefs"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_DISPLAY_NAME = "display_name"
        private const val KEY_IS_OWNER = "is_owner"
        private const val KEY_PUBLIC_KEY = "public_key"
        private const val KEY_PRIVATE_KEY = "private_key"
    }

    val deviceId: String
    var displayName: String
        get() = prefs.getString(KEY_DISPLAY_NAME, "DEVICE-${deviceId.take(4)}") ?: "SIGNAL_NODE"
        set(value) = prefs.edit().putString(KEY_DISPLAY_NAME, value).apply()

    var isOwner: Boolean
        get() = prefs.getBoolean(KEY_IS_OWNER, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_OWNER, value).apply()

    val publicKey: PublicKey
    val privateKey: PrivateKey
    val publicKeyBase64: String

    init {
        // Initialize or load device ID
        var savedId = prefs.getString(KEY_DEVICE_ID, null)
        if (savedId == null) {
            val randomHex = UUID.randomUUID().toString().replace("-", "").take(8).uppercase()
            savedId = "DEVICE-$randomHex"
            prefs.edit().putString(KEY_DEVICE_ID, savedId).apply()
        }
        deviceId = savedId

        // Initialize or load KeyPair
        val savedPub = prefs.getString(KEY_PUBLIC_KEY, null)
        val savedPriv = prefs.getString(KEY_PRIVATE_KEY, null)

        if (savedPub != null && savedPriv != null) {
            publicKey = CryptoEngine.decodePublicKey(savedPub)
            privateKey = CryptoEngine.decodePrivateKey(savedPriv)
            publicKeyBase64 = savedPub
        } else {
            val pair: KeyPair = CryptoEngine.generateKeyPair()
            publicKey = pair.public
            privateKey = pair.private
            publicKeyBase64 = CryptoEngine.encodePublicKey(publicKey)

            prefs.edit()
                .putString(KEY_PUBLIC_KEY, publicKeyBase64)
                .putString(KEY_PRIVATE_KEY, CryptoEngine.encodePrivateKey(privateKey))
                .apply()
        }
    }

    fun signData(data: String): String {
        return CryptoEngine.sign(data.toByteArray(Charsets.UTF_8), privateKey)
    }

    fun verifyData(data: String, signatureBase64: String, peerPublicKey: PublicKey): Boolean {
        return CryptoEngine.verify(data.toByteArray(Charsets.UTF_8), signatureBase64, peerPublicKey)
    }
}
