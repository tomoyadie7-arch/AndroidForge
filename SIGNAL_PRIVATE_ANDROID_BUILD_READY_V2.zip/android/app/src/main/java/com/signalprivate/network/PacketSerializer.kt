package com.signalprivate.network

import com.signalprivate.model.*
import com.signalprivate.security.CryptoEngine
import org.json.JSONArray
import org.json.JSONObject
import java.security.PrivateKey
import java.security.PublicKey

object PacketSerializer {

    fun serializePacket(packet: ProtocolPacket): String {
        val obj = JSONObject()
        obj.put("v", packet.protocolVersion)
        obj.put("type", packet.packetType.name)
        obj.put("id", packet.packetId)
        obj.put("from", packet.senderDeviceId)
        obj.put("to", packet.receiverDeviceId)
        obj.put("ts", packet.timestamp)
        obj.put("payload", packet.payloadJson)
        obj.put("sig", packet.signatureBase64)
        return obj.toString()
    }

    fun deserializePacket(jsonString: String): ProtocolPacket {
        val obj = JSONObject(jsonString)
        return ProtocolPacket(
            protocolVersion = obj.getInt("v"),
            packetType = PacketType.valueOf(obj.getString("type")),
            packetId = obj.getString("id"),
            senderDeviceId = obj.getString("from"),
            receiverDeviceId = obj.getString("to"),
            timestamp = obj.getLong("ts"),
            payloadJson = obj.getString("payload"),
            signatureBase64 = obj.optString("sig", "")
        )
    }

    /**
     * Compute data string used for packet signature:
     * canonical string: version|type|id|from|to|ts|payload
     */
    fun canonicalPayloadForSigning(packet: ProtocolPacket): String {
        return "${packet.protocolVersion}|${packet.packetType.name}|${packet.packetId}|${packet.senderDeviceId}|${packet.receiverDeviceId}|${packet.timestamp}|${packet.payloadJson}"
    }

    fun signPacket(packet: ProtocolPacket, privateKey: PrivateKey): ProtocolPacket {
        val canonical = canonicalPayloadForSigning(packet)
        val sig = CryptoEngine.sign(canonical.toByteArray(Charsets.UTF_8), privateKey)
        return packet.copy(signatureBase64 = sig)
    }

    fun verifyPacketSignature(packet: ProtocolPacket, publicKey: PublicKey): Boolean {
        if (packet.signatureBase64.isEmpty()) return false
        val canonical = canonicalPayloadForSigning(packet)
        return CryptoEngine.verify(canonical.toByteArray(Charsets.UTF_8), packet.signatureBase64, publicKey)
    }

    // --- Payload serializations using org.json ---

    fun serializeHello(hello: HelloPayload): String {
        val obj = JSONObject()
        obj.put("deviceId", hello.deviceId)
        obj.put("displayName", hello.displayName)
        obj.put("publicKey", hello.publicKeyBase64)
        obj.put("v", hello.protocolVersion)
        return obj.toString()
    }

    fun deserializeHello(json: String): HelloPayload {
        val obj = JSONObject(json)
        return HelloPayload(
            deviceId = obj.getString("deviceId"),
            displayName = obj.getString("displayName"),
            publicKeyBase64 = obj.getString("publicKey"),
            protocolVersion = obj.optInt("v", 1)
        )
    }

    fun serializePairRequest(req: PairRequestPayload): String {
        val obj = JSONObject()
        obj.put("inviteCode", req.inviteCode)
        obj.put("deviceId", req.requesterDeviceId)
        obj.put("displayName", req.requesterDisplayName)
        obj.put("publicKey", req.requesterPublicKey)
        return obj.toString()
    }

    fun deserializePairRequest(json: String): PairRequestPayload {
        val obj = JSONObject(json)
        return PairRequestPayload(
            inviteCode = obj.getString("inviteCode"),
            requesterDeviceId = obj.getString("deviceId"),
            requesterDisplayName = obj.getString("displayName"),
            requesterPublicKey = obj.getString("publicKey")
        )
    }

    fun serializePairResponse(res: PairResponsePayload): String {
        val obj = JSONObject()
        obj.put("approved", res.approved)
        obj.put("ownerDeviceId", res.ownerDeviceId)
        obj.put("ownerDisplayName", res.ownerDisplayName)
        obj.put("ownerPublicKey", res.ownerPublicKey)
        obj.put("reason", res.reason ?: "")
        return obj.toString()
    }

    fun deserializePairResponse(json: String): PairResponsePayload {
        val obj = JSONObject(json)
        return PairResponsePayload(
            approved = obj.getBoolean("approved"),
            ownerDeviceId = obj.getString("ownerDeviceId"),
            ownerDisplayName = obj.getString("ownerDisplayName"),
            ownerPublicKey = obj.getString("ownerPublicKey"),
            reason = if (obj.has("reason")) obj.getString("reason") else null
        )
    }

    fun serializeSyncRequest(sync: SyncRequestPayload): String {
        val obj = JSONObject()
        obj.put("deviceId", sync.senderDeviceId)
        val arr = JSONArray()
        sync.knownMessageIds.forEach { arr.put(it) }
        obj.put("knownIds", arr)
        return obj.toString()
    }

    fun deserializeSyncRequest(json: String): SyncRequestPayload {
        val obj = JSONObject(json)
        val arr = obj.getJSONArray("knownIds")
        val ids = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            ids.add(arr.getString(i))
        }
        return SyncRequestPayload(
            senderDeviceId = obj.getString("deviceId"),
            knownMessageIds = ids
        )
    }

    fun serializeSyncResponse(res: SyncResponsePayload): String {
        val obj = JSONObject()
        obj.put("deviceId", res.senderDeviceId)
        val arr = JSONArray()
        res.messages.forEach { m ->
            val mObj = JSONObject()
            mObj.put("id", m.messageId)
            mObj.put("convId", m.conversationId)
            mObj.put("sender", m.senderDeviceId)
            mObj.put("receiver", m.receiverDeviceId)
            mObj.put("cipher", m.encryptedBody)
            mObj.put("iv", m.ivBase64)
            mObj.put("ts", m.timestamp)
            mObj.put("status", m.status)
            arr.put(mObj)
        }
        obj.put("messages", arr)
        return obj.toString()
    }

    fun deserializeSyncResponse(json: String): SyncResponsePayload {
        val obj = JSONObject(json)
        val arr = obj.getJSONArray("messages")
        val list = mutableListOf<MessageTransferItem>()
        for (i in 0 until arr.length()) {
            val mObj = arr.getJSONObject(i)
            list.add(
                MessageTransferItem(
                    messageId = mObj.getString("id"),
                    conversationId = mObj.getString("convId"),
                    senderDeviceId = mObj.getString("sender"),
                    receiverDeviceId = mObj.getString("receiver"),
                    encryptedBody = mObj.getString("cipher"),
                    ivBase64 = mObj.getString("iv"),
                    timestamp = mObj.getLong("ts"),
                    status = mObj.getString("status")
                )
            )
        }
        return SyncResponsePayload(
            senderDeviceId = obj.getString("deviceId"),
            messages = list
        )
    }

    fun serializeMessagePayload(m: MessagePayload): String {
        val obj = JSONObject()
        obj.put("id", m.messageId)
        obj.put("convId", m.conversationId)
        obj.put("sender", m.senderDeviceId)
        obj.put("receiver", m.receiverDeviceId)
        obj.put("cipher", m.encryptedBody)
        obj.put("iv", m.ivBase64)
        obj.put("ts", m.timestamp)
        return obj.toString()
    }

    fun deserializeMessagePayload(json: String): MessagePayload {
        val obj = JSONObject(json)
        return MessagePayload(
            messageId = obj.getString("id"),
            conversationId = obj.getString("convId"),
            senderDeviceId = obj.getString("sender"),
            receiverDeviceId = obj.getString("receiver"),
            encryptedBody = obj.getString("cipher"),
            ivBase64 = obj.getString("iv"),
            timestamp = obj.getLong("ts")
        )
    }

    fun serializeMessageAck(ack: MessageAckPayload): String {
        val obj = JSONObject()
        obj.put("id", ack.messageId)
        obj.put("receiver", ack.receiverDeviceId)
        obj.put("ts", ack.deliveredTimestamp)
        return obj.toString()
    }

    fun deserializeMessageAck(json: String): MessageAckPayload {
        val obj = JSONObject(json)
        return MessageAckPayload(
            messageId = obj.getString("id"),
            receiverDeviceId = obj.getString("receiver"),
            deliveredTimestamp = obj.getLong("ts")
        )
    }

    fun serializeReadReceipt(read: ReadReceiptPayload): String {
        val obj = JSONObject()
        obj.put("id", read.messageId)
        obj.put("convId", read.conversationId)
        obj.put("reader", read.readerDeviceId)
        obj.put("ts", read.readTimestamp)
        return obj.toString()
    }

    fun deserializeReadReceipt(json: String): ReadReceiptPayload {
        val obj = JSONObject(json)
        return ReadReceiptPayload(
            messageId = obj.getString("id"),
            conversationId = obj.getString("convId"),
            readerDeviceId = obj.getString("reader"),
            readTimestamp = obj.getLong("ts")
        )
    }
}
