package com.signalprivate.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.signalprivate.SignalApplication
import com.signalprivate.model.*
import com.signalprivate.repository.SignalRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SignalViewModel(
    private val repository: SignalRepository
) : ViewModel() {

    val identityManager = repository.identityManager

    val networkDiagnostics: StateFlow<NetworkDiagnostics> = repository.networkDiagnostics
    val trustedMembers: StateFlow<List<Device>> = repository.trustedMembersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDevices: StateFlow<List<Device>> = repository.allDevicesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val discoveredPeers: StateFlow<Map<String, NetworkPeer>> = repository.discoveredPeersFlow

    val activeInviteCode: StateFlow<String?> = repository.pairingManager.activeInviteCode
    val inviteExpiresAt: StateFlow<Long?> = repository.pairingManager.inviteExpiresAt

    val pendingPairingRequests: StateFlow<List<PairingRequest>> = repository.pairingManager.pendingRequestsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val eventLogs: SharedFlow<NetworkEventLog> = repository.syncEngine.eventLogs

    fun generateInvitation(): String {
        return repository.pairingManager.generateInvitation()
    }

    fun approvePairingRequest(request: PairingRequest) {
        repository.pairingManager.approvePairing(request) {
            // Callback when approved
        }
    }

    fun rejectPairingRequest(request: PairingRequest) {
        repository.pairingManager.rejectPairing(request) {
            // Callback when rejected
        }
    }

    fun joinNetwork(targetPeer: NetworkPeer, inviteCode: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = repository.pairingManager.sendJoinRequest(targetPeer, inviteCode)
            if (result.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message)
            }
        }
    }

    fun sendMessage(peerDeviceId: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.sendMessage(peerDeviceId, text.trim())
        }
    }

    fun getMessagesForConversation(convId: String): Flow<List<Message>> {
        return repository.database.messageDao().getMessagesForConversationFlow(convId)
    }

    fun markConversationRead(convId: String, peerDeviceId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.markConversationRead(convId, peerDeviceId)
        }
    }

    fun renameDevice(deviceId: String, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.database.deviceDao().renameDevice(deviceId, newName)
        }
    }

    fun revokeDeviceTrust(deviceId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.database.deviceDao().updateTrustState(deviceId, TrustState.REVOKED)
        }
    }

    fun removeDevice(deviceId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.database.deviceDao().deleteDevice(deviceId)
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                val app = SignalApplication.instance
                return SignalViewModel(app.repository) as T
            }
        }
    }
}
