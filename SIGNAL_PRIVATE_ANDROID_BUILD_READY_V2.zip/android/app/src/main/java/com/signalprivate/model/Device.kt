package com.signalprivate.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TrustState {
    TRUSTED,
    PENDING,
    REVOKED
}

@Entity(tableName = "devices")
data class Device(
    @PrimaryKey
    val deviceId: String,
    val displayName: String,
    val publicKeyBase64: String,
    val trustState: TrustState,
    val isOwner: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastSeen: Long = System.currentTimeMillis(),
    val protocolVersion: Int = 1
)
