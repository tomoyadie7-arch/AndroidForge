package com.signalprivate.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprivate.model.InternetConnectivity
import com.signalprivate.model.LocalNetworkConnectivity
import com.signalprivate.model.NetworkEventLog
import com.signalprivate.ui.theme.*
import com.signalprivate.ui.viewmodel.SignalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun NetworkStatusScreen(
    viewModel: SignalViewModel,
    onNavigateBack: () -> Unit
) {
    val diagnostics by viewModel.networkDiagnostics.collectAsState()
    val eventLogs = remember { mutableStateListOf<NetworkEventLog>() }

    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    LaunchedEffect(Unit) {
        // Collect live events
        viewModel.eventLogs.collect { event ->
            eventLogs.add(0, event)
            if (eventLogs.size > 50) eventLogs.removeLast()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SignalDarkBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = SignalTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "NETWORK STATUS",
                style = MaterialTheme.typography.headlineLarge,
                color = SignalTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Grid of Network Status metrics
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                StatusRow(
                    label = "INTERNET",
                    value = if (diagnostics.internet == InternetConnectivity.ONLINE) "ONLINE" else "OFFLINE",
                    valueColor = if (diagnostics.internet == InternetConnectivity.ONLINE) SignalIce else SignalAmber
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "LOCAL NETWORK",
                    value = if (diagnostics.localNetwork == LocalNetworkConnectivity.CONNECTED) "CONNECTED" else "DISCONNECTED",
                    valueColor = if (diagnostics.localNetwork == LocalNetworkConnectivity.CONNECTED) SignalIce else SignalRed
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "LOCAL IP",
                    value = diagnostics.localIpAddress ?: "Not bound to interface",
                    valueColor = SignalCyan
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "DISCOVERY",
                    value = if (diagnostics.isDiscoveryActive) "ACTIVE (DNS-SD)" else "INACTIVE",
                    valueColor = if (diagnostics.isDiscoveryActive) SignalIce else SignalTextMuted
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "LOCAL PORT",
                    value = ":${diagnostics.activePort}",
                    valueColor = SignalTextSecondary
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "TRUSTED PEERS",
                    value = "${diagnostics.trustedPeersCount}",
                    valueColor = SignalTextPrimary
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "CONNECTED PEERS",
                    value = "${diagnostics.connectedPeersCount}",
                    valueColor = SignalIce
                )
                Divider(modifier = Modifier.padding(vertical = 8.dp), color = SignalBorder)

                StatusRow(
                    label = "SYNC QUEUE",
                    value = "${diagnostics.queuedMessagesCount} messages",
                    valueColor = if (diagnostics.queuedMessagesCount > 0) SignalAmber else SignalTextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "LIVE EVENT LOG",
            style = MaterialTheme.typography.labelSmall,
            color = SignalTextSecondary
        )
        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            shape = RoundedCornerShape(8.dp),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            if (eventLogs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Listening for local network events and peer handshakes...",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalTextMuted
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(eventLogs) { log ->
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = timeFormat.format(Date(log.timestamp)),
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalCyan,
                                modifier = Modifier.width(68.dp)
                            )
                            Text(
                                text = log.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = SignalTextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusRow(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = SignalTextMuted
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = valueColor,
            fontWeight = FontWeight.Bold
        )
    }
}
