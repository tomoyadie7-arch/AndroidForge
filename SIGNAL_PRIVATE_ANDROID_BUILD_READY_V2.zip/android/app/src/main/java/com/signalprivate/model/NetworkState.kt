package com.signalprivate.model

enum class InternetConnectivity {
    ONLINE,
    OFFLINE
}

enum class LocalNetworkConnectivity {
    CONNECTED,
    DISCONNECTED
}

enum class SignalMeshStatus {
    ONLINE,
    DISCOVERING,
    OFFLINE
}

data class NetworkDiagnostics(
    val internet: InternetConnectivity = InternetConnectivity.OFFLINE,
    val localNetwork: LocalNetworkConnectivity = LocalNetworkConnectivity.DISCONNECTED,
    val signal: SignalMeshStatus = SignalMeshStatus.OFFLINE,
    val localIpAddress: String? = null,
    val isDiscoveryActive: Boolean = false,
    val trustedPeersCount: Int = 0,
    val connectedPeersCount: Int = 0,
    val queuedMessagesCount: Int = 0,
    val activePort: Int = 42424
)

data class NetworkEventLog(
    val timestamp: Long = System.currentTimeMillis(),
    val message: String
)
