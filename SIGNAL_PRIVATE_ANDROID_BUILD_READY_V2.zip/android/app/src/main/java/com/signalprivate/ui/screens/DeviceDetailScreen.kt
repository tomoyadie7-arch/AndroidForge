package com.signalprivate.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprivate.model.TrustState
import com.signalprivate.security.CryptoEngine
import com.signalprivate.ui.theme.*
import com.signalprivate.ui.viewmodel.SignalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DeviceDetailScreen(
    deviceId: String,
    viewModel: SignalViewModel,
    onNavigateBack: () -> Unit
) {
    val devices by viewModel.allDevices.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()

    val device = devices.find { it.deviceId == deviceId }
    val isOnline = discoveredPeers.containsKey(deviceId)

    var showRenameDialog by remember { mutableStateOf(false) }
    var renameInput by remember { mutableStateOf(device?.displayName ?: "") }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SignalDarkBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = SignalTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DEVICE DETAILS",
                style = MaterialTheme.typography.headlineLarge,
                color = SignalTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (device == null) {
            Text("Device not found.", color = SignalTextSecondary)
            return
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                DetailItem(label = "DISPLAY NAME", value = device.displayName)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = SignalBorder)

                DetailItem(label = "DEVICE ID", value = device.deviceId)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = SignalBorder)

                DetailItem(label = "TRUST STATUS", value = device.trustState.name)
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = SignalBorder)

                DetailItem(
                    label = "LOCAL CONNECTION",
                    value = if (isOnline) "ONLINE (LAN)" else "OFFLINE"
                )
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = SignalBorder)

                DetailItem(
                    label = "LAST SEEN",
                    value = dateFormat.format(Date(device.lastSeen))
                )
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = SignalBorder)

                DetailItem(
                    label = "PROTOCOL VERSION",
                    value = "v${device.protocolVersion}"
                )
                Divider(modifier = Modifier.padding(vertical = 10.dp), color = SignalBorder)

                DetailItem(
                    label = "PUBLIC KEY FINGERPRINT",
                    value = CryptoEngine.getFingerprint(device.publicKeyBase64)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Owner Actions
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { showRenameDialog = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SignalSurfaceElevated,
                    contentColor = SignalCyan
                )
            ) {
                Text("RENAME", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            if (device.trustState == TrustState.TRUSTED) {
                Button(
                    onClick = {
                        viewModel.revokeDeviceTrust(deviceId)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SignalAmber.copy(alpha = 0.2f),
                        contentColor = SignalAmber
                    )
                ) {
                    Text("REVOKE TRUST", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Button(
                onClick = {
                    viewModel.removeDevice(deviceId)
                    onNavigateBack()
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(6.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SignalRed.copy(alpha = 0.2f),
                    contentColor = SignalRed
                )
            ) {
                Text("REMOVE DEVICE", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }

    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Member", color = SignalTextPrimary) },
            text = {
                OutlinedTextField(
                    value = renameInput,
                    onValueChange = { renameInput = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = SignalTextPrimary,
                        unfocusedTextColor = SignalTextPrimary
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (renameInput.isNotBlank()) {
                            viewModel.renameDevice(deviceId, renameInput.trim())
                            showRenameDialog = false
                        }
                    }
                ) {
                    Text("SAVE", color = SignalCyan)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("CANCEL", color = SignalTextMuted)
                }
            },
            containerColor = SignalDarkSurface
        )
    }
}

@Composable
fun DetailItem(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = SignalTextMuted,
            fontSize = 9.sp
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = SignalTextPrimary,
            fontWeight = FontWeight.Medium
        )
    }
}
