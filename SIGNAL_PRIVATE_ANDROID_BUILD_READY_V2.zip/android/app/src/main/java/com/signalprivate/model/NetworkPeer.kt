package com.signalprivate.model

data class NetworkPeer(
    val deviceId: String,
    val displayName: String,
    val hostAddress: String,
    val port: Int,
    val protocolVersion: Int = 1,
    val lastDiscoveredAt: Long = System.currentTimeMillis(),
    val isConnected: Boolean = false,
    val isTrusted: Boolean = false
)

enum class PeerConnectionStatus {
    DISCONNECTED,
    CONNECTING,
    AUTHENTICATED,
    SYNCING
}
