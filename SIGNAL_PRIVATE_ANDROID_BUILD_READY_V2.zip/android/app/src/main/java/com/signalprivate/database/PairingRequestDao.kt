package com.signalprivate.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.signalprivate.model.PairingRequest
import com.signalprivate.model.PairingStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface PairingRequestDao {
    @Query("SELECT * FROM pairing_requests WHERE status = 'ACTIVE' ORDER BY createdAt DESC")
    fun getActiveRequestsFlow(): Flow<List<PairingRequest>>

    @Query("SELECT * FROM pairing_requests WHERE temporaryCode = :code AND status = 'ACTIVE' LIMIT 1")
    suspend fun getActiveRequestByCode(code: String): PairingRequest?

    @Query("SELECT * FROM pairing_requests WHERE requesterDeviceId = :deviceId LIMIT 1")
    suspend fun getRequestByRequesterId(deviceId: String): PairingRequest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(request: PairingRequest)

    @Update
    suspend fun update(request: PairingRequest)

    @Query("UPDATE pairing_requests SET status = :status WHERE requestId = :id")
    suspend fun updateStatus(id: String, status: PairingStatus)

    @Query("UPDATE pairing_requests SET status = 'EXPIRED' WHERE status = 'ACTIVE' AND expiresAt < :now")
    suspend fun expireOldRequests(now: Long = System.currentTimeMillis())

    @Query("DELETE FROM pairing_requests WHERE expiresAt < :olderThan")
    suspend fun cleanUpOld(olderThan: Long)
}
