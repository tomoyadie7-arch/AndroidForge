package com.signalprivate.network

import android.util.Log
import com.signalprivate.model.ProtocolPacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException

class TransportServer(
    private val preferredPort: Int = 42424,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "SignalServer"
        private const val MAX_PACKET_SIZE = 10 * 1024 * 1024 // 10MB limit for safety
    }

    private var serverSocket: ServerSocket? = null
    var activePort: Int = preferredPort
        private set

    var onPacketReceived: ((packet: ProtocolPacket, respond: (ProtocolPacket) -> Unit) -> Unit)? = null

    fun start(): Int {
        try {
            serverSocket = ServerSocket(preferredPort).apply {
                reuseAddress = true
            }
            activePort = serverSocket!!.localPort
            Log.i(TAG, "TransportServer listening on port $activePort")
        } catch (e: Exception) {
            Log.w(TAG, "Could not bind to preferred port $preferredPort, binding to dynamic port...")
            serverSocket = ServerSocket(0).apply {
                reuseAddress = true
            }
            activePort = serverSocket!!.localPort
            Log.i(TAG, "TransportServer listening on fallback port $activePort")
        }

        scope.launch(Dispatchers.IO) {
            while (isActive && serverSocket?.isClosed == false) {
                try {
                    val clientSocket = serverSocket?.accept() ?: break
                    launch(Dispatchers.IO) {
                        handleClientConnection(clientSocket)
                    }
                } catch (e: SocketException) {
                    // Server socket closed
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Exception accepting socket connection", e)
                }
            }
        }

        return activePort
    }

    private fun handleClientConnection(socket: Socket) {
        try {
            socket.soTimeout = 15000 // 15s timeout
            val inputStream = DataInputStream(socket.getInputStream())
            val outputStream = DataOutputStream(socket.getOutputStream())

            while (socket.isConnected && !socket.isClosed) {
                val length = try {
                    inputStream.readInt()
                } catch (e: EOFException) {
                    break
                } catch (e: Exception) {
                    break
                }

                if (length <= 0 || length > MAX_PACKET_SIZE) {
                    Log.w(TAG, "Invalid packet length received: $length")
                    break
                }

                val buffer = ByteArray(length)
                inputStream.readFully(buffer)
                val jsonString = String(buffer, Charsets.UTF_8)

                val packet = PacketSerializer.deserializePacket(jsonString)
                Log.d(TAG, "Received packet ${packet.packetType} from ${packet.senderDeviceId}")

                onPacketReceived?.invoke(packet) { responsePacket ->
                    try {
                        val responseJson = PacketSerializer.serializePacket(responsePacket)
                        val responseBytes = responseJson.toByteArray(Charsets.UTF_8)
                        synchronized(outputStream) {
                            outputStream.writeInt(responseBytes.size)
                            outputStream.write(responseBytes)
                            outputStream.flush()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to send response packet", e)
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Client socket finished or closed: ${e.message}")
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing server socket", e)
        } finally {
            serverSocket = null
        }
    }
}
