package com.signalprivate.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.signalprivate.model.Device
import com.signalprivate.model.TrustState
import kotlinx.coroutines.flow.Flow

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY displayName ASC")
    fun getAllDevicesFlow(): Flow<List<Device>>

    @Query("SELECT * FROM devices WHERE trustState = 'TRUSTED' ORDER BY displayName ASC")
    fun getTrustedDevicesFlow(): Flow<List<Device>>

    @Query("SELECT * FROM devices WHERE trustState = 'TRUSTED'")
    suspend fun getTrustedDevices(): List<Device>

    @Query("SELECT * FROM devices WHERE deviceId = :deviceId LIMIT 1")
    suspend fun getDeviceById(deviceId: String): Device?

    @Query("SELECT * FROM devices WHERE deviceId = :deviceId LIMIT 1")
    fun getDeviceByIdFlow(deviceId: String): Flow<Device?>

    @Query("SELECT * FROM devices WHERE isOwner = 1 LIMIT 1")
    suspend fun getOwnerDevice(): Device?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(device: Device)

    @Update
    suspend fun update(device: Device)

    @Query("UPDATE devices SET trustState = :newState WHERE deviceId = :deviceId")
    suspend fun updateTrustState(deviceId: String, newState: TrustState)

    @Query("UPDATE devices SET displayName = :newName WHERE deviceId = :deviceId")
    suspend fun renameDevice(deviceId: String, newName: String)

    @Query("UPDATE devices SET lastSeen = :timestamp WHERE deviceId = :deviceId")
    suspend fun updateLastSeen(deviceId: String, timestamp: Long)

    @Query("DELETE FROM devices WHERE deviceId = :deviceId")
    suspend fun deleteDevice(deviceId: String)

    @Query("SELECT COUNT(*) FROM devices WHERE trustState = 'TRUSTED'")
    fun getTrustedCountFlow(): Flow<Int>
}
