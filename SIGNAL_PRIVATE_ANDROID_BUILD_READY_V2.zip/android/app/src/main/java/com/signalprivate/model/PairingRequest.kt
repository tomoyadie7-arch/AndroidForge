package com.signalprivate.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class PairingStatus {
    ACTIVE,
    APPROVED,
    REJECTED,
    EXPIRED
}

@Entity(tableName = "pairing_requests")
data class PairingRequest(
    @PrimaryKey
    val requestId: String,
    val temporaryCode: String,
    val requesterDeviceId: String,
    val requesterName: String,
    val requesterPublicKey: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 10 * 60 * 1000L, // 10 minutes
    val status: PairingStatus = PairingStatus.ACTIVE
) {
    val isExpired: Boolean
        get() = System.currentTimeMillis() > expiresAt
}
