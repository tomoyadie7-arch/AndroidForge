package com.signalprivate.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.signalprivate.model.Message
import com.signalprivate.model.MessageStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt ASC")
    fun getMessagesForConversationFlow(conversationId: String): Flow<List<Message>>

    @Query("SELECT * FROM messages WHERE receiverDeviceId = :receiverId AND status IN ('QUEUED', 'SENDING') ORDER BY createdAt ASC")
    suspend fun getQueuedMessagesForDevice(receiverId: String): List<Message>

    @Query("SELECT * FROM messages WHERE status = 'QUEUED' ORDER BY createdAt ASC")
    suspend fun getAllQueuedMessages(): List<Message>

    @Query("SELECT COUNT(*) FROM messages WHERE status = 'QUEUED'")
    fun getQueuedCountFlow(): Flow<Int>

    @Query("SELECT * FROM messages WHERE messageId = :messageId LIMIT 1")
    suspend fun getMessageById(messageId: String): Message?

    @Query("SELECT messageId FROM messages WHERE conversationId = :conversationId")
    suspend fun getMessageIdsForConversation(conversationId: String): List<String>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAt DESC LIMIT :limit")
    suspend fun getRecentMessages(conversationId: String, limit: Int = 100): List<Message>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(message: Message): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMessage(message: Message)

    @Update
    suspend fun updateMessage(message: Message)

    @Query("UPDATE messages SET status = :status WHERE messageId = :messageId")
    suspend fun updateStatus(messageId: String, status: MessageStatus)

    @Query("UPDATE messages SET status = 'DELIVERED', deliveryTimestamp = :timestamp WHERE messageId = :messageId AND status != 'READ'")
    suspend fun markDelivered(messageId: String, timestamp: Long)

    @Query("UPDATE messages SET status = 'READ', readTimestamp = :timestamp WHERE messageId = :messageId")
    suspend fun markRead(messageId: String, timestamp: Long)

    @Query("UPDATE messages SET status = 'READ', readTimestamp = :timestamp WHERE conversationId = :conversationId AND receiverDeviceId = :myDeviceId AND status != 'READ'")
    suspend fun markConversationAsRead(conversationId: String, myDeviceId: String, timestamp: Long)

    @Query("UPDATE messages SET retryCount = retryCount + 1, lastAttemptAt = :now WHERE messageId = :messageId")
    suspend fun recordRetryAttempt(messageId: String, now: Long = System.currentTimeMillis())
}
