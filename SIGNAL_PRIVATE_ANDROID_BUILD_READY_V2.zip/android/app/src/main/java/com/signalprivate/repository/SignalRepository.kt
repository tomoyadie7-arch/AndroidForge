package com.signalprivate.repository

import android.content.Context
import android.util.Log
import com.signalprivate.database.AppDatabase
import com.signalprivate.model.*
import com.signalprivate.network.*
import com.signalprivate.pairing.PairingManager
import com.signalprivate.security.CryptoEngine
import com.signalprivate.security.IdentityManager
import com.signalprivate.sync.OfflineQueueManager
import com.signalprivate.sync.SyncEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.UUID

class SignalRepository(
    private val context: Context,
    val database: AppDatabase,
    val identityManager: IdentityManager,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "SignalRepo"
    }

    val transportClient = TransportClient()
    val transportServer = TransportServer(preferredPort = 42424, scope = scope)
    val discoveryManager = NsdDiscoveryManager(
        context = context,
        myDeviceId = identityManager.deviceId,
        myDisplayName = identityManager.displayName,
        scope = scope
    )
    val networkMonitor = NetworkMonitor(context)
    val pairingManager = PairingManager(database, identityManager, transportClient, scope)
    val syncEngine = SyncEngine(database, identityManager, transportClient, scope)

    val offlineQueueManager = OfflineQueueManager(
        database = database,
        scope = scope,
        sendQueuedMessageAction = { msg, peer ->
            deliverMessageDirect(msg, peer)
        }
    )

    val trustedMembersFlow: Flow<List<Device>> = database.deviceDao().getTrustedDevicesFlow()
    val allDevicesFlow: Flow<List<Device>> = database.deviceDao().getAllDevicesFlow()
    val discoveredPeersFlow: StateFlow<Map<String, NetworkPeer>> = discoveryManager.discoveredPeers

    private val _networkDiagnostics = MutableStateFlow(NetworkDiagnostics())
    val networkDiagnostics: StateFlow<NetworkDiagnostics> = _networkDiagnostics.asStateFlow()

    init {
        setupPacketRouting()
        setupPeerDiscoveryCallbacks()
        observeDiagnostics()
    }

    fun start() {
        Log.i(TAG, "Starting SIGNAL // PRIVATE network stack...")
        val port = transportServer.start()
        networkMonitor.start()
        discoveryManager.registerService(port)
        discoveryManager.startDiscovery()
        offlineQueueManager.startQueueSupervisor { discoveryManager.discoveredPeers.value }
    }

    fun stop() {
        Log.i(TAG, "Stopping SIGNAL // PRIVATE network stack...")
        offlineQueueManager.stop()
        discoveryManager.stopAll()
        transportServer.stop()
        networkMonitor.stop()
    }

    private fun setupPeerDiscoveryCallbacks() {
        discoveryManager.onPeerDiscovered = { peer ->
            Log.i(TAG, "Discovered LAN peer: ${peer.displayName} (${peer.deviceId}) at ${peer.hostAddress}:${peer.port}")
            scope.launch(Dispatchers.IO) {
                // If peer is trusted, trigger 2-way sync and flush offline queue
                val device = database.deviceDao().getDeviceById(peer.deviceId)
                if (device?.trustState == TrustState.TRUSTED) {
                    database.deviceDao().updateLastSeen(peer.deviceId, System.currentTimeMillis())
                    syncEngine.synchronizeWithPeer(peer)
                    offlineQueueManager.onPeerAvailable(peer)
                }
            }
        }

        discoveryManager.onPeerLost = { peerId ->
            Log.i(TAG, "Peer lost on LAN: $peerId")
        }
    }

    private fun setupPacketRouting() {
        transportServer.onPacketReceived = { packet, respond ->
            scope.launch(Dispatchers.IO) {
                handleIncomingPacket(packet, respond)
            }
        }
    }

    private suspend fun handleIncomingPacket(packet: ProtocolPacket, respond: (ProtocolPacket) -> Unit) {
        when (packet.packetType) {
            PacketType.HELLO -> {
                val hello = PacketSerializer.deserializeHello(packet.payloadJson)
                val peerDevice = database.deviceDao().getDeviceById(hello.deviceId)
                val respHello = HelloPayload(
                    deviceId = identityManager.deviceId,
                    displayName = identityManager.displayName,
                    publicKeyBase64 = identityManager.publicKeyBase64
                )
                val resp = ProtocolPacket(
                    protocolVersion = 1,
                    packetType = PacketType.HELLO_ACK,
                    packetId = UUID.randomUUID().toString(),
                    senderDeviceId = identityManager.deviceId,
                    receiverDeviceId = packet.senderDeviceId,
                    payloadJson = PacketSerializer.serializeHello(respHello)
                )
                respond(PacketSerializer.signPacket(resp, identityManager.privateKey))
            }

            PacketType.PAIR_REQUEST -> {
                pairingManager.handleIncomingPairRequest(packet, respond)
            }

            PacketType.SYNC_REQUEST -> {
                syncEngine.handleSyncRequest(packet, respond)
            }

            PacketType.MESSAGE -> {
                handleIncomingMessage(packet, respond)
            }

            PacketType.MESSAGE_ACK -> {
                val ack = PacketSerializer.deserializeMessageAck(packet.payloadJson)
                database.messageDao().markDelivered(ack.messageId, ack.deliveredTimestamp)
                Log.d(TAG, "Message ${ack.messageId} marked DELIVERED")
            }

            PacketType.READ_RECEIPT -> {
                val read = PacketSerializer.deserializeReadReceipt(packet.payloadJson)
                database.messageDao().markRead(read.messageId, read.readTimestamp)
                Log.d(TAG, "Message ${read.messageId} marked READ")
            }

            PacketType.PING -> {
                val pong = ProtocolPacket(
                    protocolVersion = 1,
                    packetType = PacketType.PONG,
                    packetId = UUID.randomUUID().toString(),
                    senderDeviceId = identityManager.deviceId,
                    receiverDeviceId = packet.senderDeviceId,
                    payloadJson = "{}"
                )
                respond(pong)
            }

            else -> {
                Log.w(TAG, "Unhandled packet type: ${packet.packetType}")
            }
        }
    }

    private suspend fun handleIncomingMessage(packet: ProtocolPacket, respond: (ProtocolPacket) -> Unit) {
        val senderDevice = database.deviceDao().getDeviceById(packet.senderDeviceId)
        if (senderDevice == null || senderDevice.trustState != TrustState.TRUSTED) {
            Log.w(TAG, "Rejected message from untrusted sender: ${packet.senderDeviceId}")
            return
        }

        // Verify sender packet signature
        val senderPubKey = CryptoEngine.decodePublicKey(senderDevice.publicKeyBase64)
        if (!PacketSerializer.verifyPacketSignature(packet, senderPubKey)) {
            Log.e(TAG, "Invalid cryptographic signature on message from ${senderDevice.displayName}!")
            return
        }

        val msgPayload = PacketSerializer.deserializeMessagePayload(packet.payloadJson)

        // Decrypt using shared secret derived from peer's public key
        val sharedKey = CryptoEngine.deriveSharedSecret(identityManager.privateKey, senderPubKey)
        val decryptedText = try {
            CryptoEngine.decrypt(
                com.signalprivate.security.EncryptedPayload(msgPayload.encryptedBody, msgPayload.ivBase64),
                sharedKey
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed decrypting message payload", e)
            "[Decryption Failed]"
        }

        val conversationId = msgPayload.conversationId
        val message = Message(
            messageId = msgPayload.messageId,
            conversationId = conversationId,
            senderDeviceId = msgPayload.senderDeviceId,
            receiverDeviceId = identityManager.deviceId,
            body = decryptedText,
            createdAt = msgPayload.timestamp,
            status = MessageStatus.DELIVERED
        )

        // Idempotent insertion
        database.messageDao().insertMessage(message)

        // Update conversation preview
        val existingConv = database.conversationDao().getConversationById(conversationId)
        if (existingConv == null) {
            database.conversationDao().insertOrUpdate(
                Conversation(
                    conversationId = conversationId,
                    peerDeviceId = senderDevice.deviceId,
                    lastMessageAt = msgPayload.timestamp,
                    lastMessagePreview = decryptedText,
                    unreadCount = 1
                )
            )
        } else {
            database.conversationDao().updateLastMessage(conversationId, msgPayload.timestamp, decryptedText)
            database.conversationDao().incrementUnreadCount(conversationId)
        }

        database.deviceDao().updateLastSeen(senderDevice.deviceId, System.currentTimeMillis())

        // Immediate DELIVERY ACKNOWLEDGMENT back to sender
        val ackPayload = MessageAckPayload(
            messageId = msgPayload.messageId,
            receiverDeviceId = identityManager.deviceId,
            deliveredTimestamp = System.currentTimeMillis()
        )
        val ackPacket = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.MESSAGE_ACK,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = packet.senderDeviceId,
            payloadJson = PacketSerializer.serializeMessageAck(ackPayload)
        )
        respond(PacketSerializer.signPacket(ackPacket, identityManager.privateKey))
    }

    /**
     * Send message from UI:
     * - Saves into Room
     * - If peer is discovered on LAN: sends immediately and marks SENT -> DELIVERED
     * - If peer is offline: saves as QUEUED. OfflineQueueManager will auto-flush when peer appears!
     */
    suspend fun sendMessage(peerDeviceId: String, body: String): Message = withContext(Dispatchers.IO) {
        val convId = "conv_$peerDeviceId"
        val messageId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()

        val peerDevice = database.deviceDao().getDeviceById(peerDeviceId)
            ?: throw IllegalStateException("Device not found")

        val peer = discoveryManager.discoveredPeers.value[peerDeviceId]
        val initialStatus = if (peer != null) MessageStatus.SENDING else MessageStatus.QUEUED

        val message = Message(
            messageId = messageId,
            conversationId = convId,
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = peerDeviceId,
            body = body,
            createdAt = now,
            status = initialStatus
        )

        database.messageDao().insertMessage(message)
        database.conversationDao().updateLastMessage(convId, now, body)

        if (peer != null) {
            scope.launch(Dispatchers.IO) {
                deliverMessageDirect(message, peer)
            }
        } else {
            Log.i(TAG, "Peer $peerDeviceId is offline on LAN. Message $messageId stored in offline queue (status=QUEUED).")
        }

        message
    }

    /**
     * Directly transports encrypted message to peer.
     */
    private suspend fun deliverMessageDirect(message: Message, peer: NetworkPeer): Boolean {
        val peerDevice = database.deviceDao().getDeviceById(peer.deviceId) ?: return false
        val peerPubKey = CryptoEngine.decodePublicKey(peerDevice.publicKeyBase64)
        val sharedKey = CryptoEngine.deriveSharedSecret(identityManager.privateKey, peerPubKey)

        val encrypted = CryptoEngine.encrypt(message.body, sharedKey)
        val payload = MessagePayload(
            messageId = message.messageId,
            conversationId = message.conversationId,
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = peer.deviceId,
            encryptedBody = encrypted.ciphertextBase64,
            ivBase64 = encrypted.ivBase64,
            timestamp = message.createdAt
        )

        val packet = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.MESSAGE,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = peer.deviceId,
            payloadJson = PacketSerializer.serializeMessagePayload(payload)
        )

        val signedPacket = PacketSerializer.signPacket(packet, identityManager.privateKey)
        val result = transportClient.sendAndReceive(peer.hostAddress, peer.port, signedPacket)

        return if (result.isSuccess) {
            val response = result.getOrNull()
            if (response?.packetType == PacketType.MESSAGE_ACK) {
                val ack = PacketSerializer.deserializeMessageAck(response.payloadJson)
                database.messageDao().markDelivered(message.messageId, ack.deliveredTimestamp)
            } else {
                database.messageDao().updateStatus(message.messageId, MessageStatus.SENT)
            }
            true
        } else {
            database.messageDao().updateStatus(message.messageId, MessageStatus.QUEUED)
            false
        }
    }

    /**
     * Send read receipt when user opens chat.
     */
    suspend fun markConversationRead(conversationId: String, peerDeviceId: String) = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        database.messageDao().markConversationAsRead(conversationId, identityManager.deviceId, now)
        database.conversationDao().resetUnreadCount(conversationId)

        val peer = discoveryManager.discoveredPeers.value[peerDeviceId]
        if (peer != null) {
            val readPayload = ReadReceiptPayload(
                messageId = "*",
                conversationId = conversationId,
                readerDeviceId = identityManager.deviceId,
                readTimestamp = now
            )
            val packet = ProtocolPacket(
                protocolVersion = 1,
                packetType = PacketType.READ_RECEIPT,
                packetId = UUID.randomUUID().toString(),
                senderDeviceId = identityManager.deviceId,
                receiverDeviceId = peerDeviceId,
                payloadJson = PacketSerializer.serializeReadReceipt(readPayload)
            )
            val signed = PacketSerializer.signPacket(packet, identityManager.privateKey)
            transportClient.sendOneWay(peer.hostAddress, peer.port, signed)
        }
    }

    private fun observeDiagnostics() {
        scope.launch {
            combine(
                networkMonitor.internetStatus,
                networkMonitor.localNetworkStatus,
                networkMonitor.localIpAddress,
                discoveryManager.isDiscovering,
                database.deviceDao().getTrustedCountFlow(),
                discoveryManager.discoveredPeers,
                database.messageDao().getQueuedCountFlow()
            ) { internet, local, ip, discovering, trustedCount, peers, queuedCount ->
                NetworkDiagnostics(
                    internet = internet,
                    localNetwork = local,
                    signal = if (discovering) SignalMeshStatus.ONLINE else SignalMeshStatus.OFFLINE,
                    localIpAddress = ip,
                    isDiscoveryActive = discovering,
                    trustedPeersCount = trustedCount,
                    connectedPeersCount = peers.size,
                    queuedMessagesCount = queuedCount,
                    activePort = transportServer.activePort
                )
            }.collect { diagnostics ->
                _networkDiagnostics.value = diagnostics
            }
        }
    }
}
