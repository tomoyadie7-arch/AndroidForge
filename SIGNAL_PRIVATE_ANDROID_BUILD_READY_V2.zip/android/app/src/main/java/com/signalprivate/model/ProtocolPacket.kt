package com.signalprivate.model

enum class PacketType {
    HELLO,
    HELLO_ACK,
    AUTH_CHALLENGE,
    AUTH_RESPONSE,
    PAIR_REQUEST,
    PAIR_RESPONSE,
    SYNC_REQUEST,
    SYNC_RESPONSE,
    MESSAGE,
    MESSAGE_ACK,
    READ_RECEIPT,
    PING,
    PONG
}

data class ProtocolPacket(
    val protocolVersion: Int = 1,
    val packetType: PacketType,
    val packetId: String,
    val senderDeviceId: String,
    val receiverDeviceId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val payloadJson: String,
    val signatureBase64: String = ""
)

// Payloads for specific packets:
data class HelloPayload(
    val deviceId: String,
    val displayName: String,
    val publicKeyBase64: String,
    val protocolVersion: Int = 1
)

data class AuthPayload(
    val challenge: String,
    val responseSignature: String? = null
)

data class PairRequestPayload(
    val inviteCode: String,
    val requesterDeviceId: String,
    val requesterDisplayName: String,
    val requesterPublicKey: String
)

data class PairResponsePayload(
    val approved: Boolean,
    val ownerDeviceId: String,
    val ownerDisplayName: String,
    val ownerPublicKey: String,
    val reason: String? = null
)

data class SyncRequestPayload(
    val senderDeviceId: String,
    val knownMessageIds: List<String>
)

data class SyncResponsePayload(
    val senderDeviceId: String,
    val messages: List<MessageTransferItem>
)

data class MessagePayload(
    val messageId: String,
    val conversationId: String,
    val senderDeviceId: String,
    val receiverDeviceId: String,
    val encryptedBody: String,
    val ivBase64: String,
    val timestamp: Long
)

data class MessageAckPayload(
    val messageId: String,
    val receiverDeviceId: String,
    val deliveredTimestamp: Long
)

data class ReadReceiptPayload(
    val messageId: String,
    val conversationId: String,
    val readerDeviceId: String,
    val readTimestamp: Long
)

data class MessageTransferItem(
    val messageId: String,
    val conversationId: String,
    val senderDeviceId: String,
    val receiverDeviceId: String,
    val encryptedBody: String,
    val ivBase64: String,
    val timestamp: Long,
    val status: String
)
