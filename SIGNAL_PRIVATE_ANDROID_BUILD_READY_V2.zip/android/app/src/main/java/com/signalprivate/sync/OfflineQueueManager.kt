package com.signalprivate.sync

import android.util.Log
import com.signalprivate.database.AppDatabase
import com.signalprivate.model.Message
import com.signalprivate.model.MessageStatus
import com.signalprivate.model.NetworkPeer
import com.signalprivate.model.TrustState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class OfflineQueueManager(
    private val database: AppDatabase,
    private val scope: CoroutineScope,
    private val sendQueuedMessageAction: suspend (Message, NetworkPeer) -> Boolean
) {
    companion object {
        private const val TAG = "SignalQueue"
        private const val BASE_BACKOFF_MS = 2000L
        private const val MAX_BACKOFF_MS = 60000L
    }

    private var queueWorkerJob: Job? = null
    val queuedCountFlow: Flow<Int> = database.messageDao().getQueuedCountFlow()

    /**
     * Trigger queue drain whenever a trusted peer is discovered or reconnected.
     */
    fun onPeerAvailable(peer: NetworkPeer) {
        scope.launch(Dispatchers.IO) {
            val device = database.deviceDao().getDeviceById(peer.deviceId)
            if (device == null || device.trustState != TrustState.TRUSTED) {
                Log.d(TAG, "Peer ${peer.deviceId} is not trusted, skipping queue flush")
                return@launch
            }

            val queued = database.messageDao().getQueuedMessagesForDevice(peer.deviceId)
            if (queued.isEmpty()) return@launch

            Log.i(TAG, "Found ${queued.size} queued messages for peer ${peer.displayName}. Flushing queue...")

            for (msg in queued) {
                try {
                    database.messageDao().updateStatus(msg.messageId, MessageStatus.SENDING)
                    val success = sendQueuedMessageAction(msg, peer)
                    if (success) {
                        Log.i(TAG, "Queued message ${msg.messageId} successfully delivered to ${peer.displayName}")
                    } else {
                        Log.w(TAG, "Failed delivery for message ${msg.messageId}, marking back to QUEUED with retry")
                        database.messageDao().updateStatus(msg.messageId, MessageStatus.QUEUED)
                        database.messageDao().recordRetryAttempt(msg.messageId)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error flushing message ${msg.messageId}", e)
                    database.messageDao().updateStatus(msg.messageId, MessageStatus.QUEUED)
                    database.messageDao().recordRetryAttempt(msg.messageId)
                }
            }
        }
    }

    /**
     * Starts periodic retry supervisor with exponential backoff.
     */
    fun startQueueSupervisor(getAvailablePeers: () -> Map<String, NetworkPeer>) {
        queueWorkerJob?.cancel()
        queueWorkerJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(5000L)
                try {
                    val queuedMessages = database.messageDao().getAllQueuedMessages()
                    if (queuedMessages.isEmpty()) continue

                    val peers = getAvailablePeers()
                    val now = System.currentTimeMillis()

                    for (msg in queuedMessages) {
                        val peer = peers[msg.receiverDeviceId]
                        if (peer != null) {
                            // Calculate backoff: min(MAX, BASE * 2^retryCount)
                            val backoff = (BASE_BACKOFF_MS * (1 shl msg.retryCount.coerceAtMost(6)))
                                .coerceAtMost(MAX_BACKOFF_MS)

                            if (now - msg.lastAttemptAt >= backoff) {
                                database.messageDao().updateStatus(msg.messageId, MessageStatus.SENDING)
                                val success = sendQueuedMessageAction(msg, peer)
                                if (success) {
                                    Log.i(TAG, "Periodic sync: Message ${msg.messageId} sent to ${peer.displayName}")
                                } else {
                                    database.messageDao().updateStatus(msg.messageId, MessageStatus.QUEUED)
                                    database.messageDao().recordRetryAttempt(msg.messageId, now)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in queue supervisor loop", e)
                }
            }
        }
    }

    fun stop() {
        queueWorkerJob?.cancel()
        queueWorkerJob = null
    }
}
