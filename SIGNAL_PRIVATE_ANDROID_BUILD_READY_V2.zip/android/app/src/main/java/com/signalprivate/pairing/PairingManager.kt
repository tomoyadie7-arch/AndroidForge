package com.signalprivate.pairing

import android.util.Log
import com.signalprivate.database.AppDatabase
import com.signalprivate.model.*
import com.signalprivate.network.PacketSerializer
import com.signalprivate.network.TransportClient
import com.signalprivate.security.CryptoEngine
import com.signalprivate.security.IdentityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class PairingManager(
    private val database: AppDatabase,
    private val identityManager: IdentityManager,
    private val transportClient: TransportClient,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "SignalPairing"
    }

    private val _activeInviteCode = MutableStateFlow<String?>(null)
    val activeInviteCode: StateFlow<String?> = _activeInviteCode.asStateFlow()

    private val _inviteExpiresAt = MutableStateFlow<Long?>(null)
    val inviteExpiresAt: StateFlow<Long?> = _inviteExpiresAt.asStateFlow()

    val pendingRequestsFlow: Flow<List<PairingRequest>> =
        database.pairingRequestDao().getActiveRequestsFlow()

    /**
     * Owner generates a new 10-minute pairing invitation code.
     */
    fun generateInvitation(): String {
        val code = CryptoEngine.generateInvitationCode()
        val expiresAt = System.currentTimeMillis() + 10 * 60 * 1000L
        _activeInviteCode.value = code
        _inviteExpiresAt.value = expiresAt
        Log.i(TAG, "Generated pairing invitation: $code (expires in 10 min)")
        return code
    }

    fun clearActiveInvitation() {
        _activeInviteCode.value = null
        _inviteExpiresAt.value = null
    }

    /**
     * Member initiates a join request using an invite code and targets a discovered peer.
     */
    suspend fun sendJoinRequest(
        targetPeer: NetworkPeer,
        inviteCode: String
    ): Result<Boolean> {
        val payload = PairRequestPayload(
            inviteCode = inviteCode.trim().uppercase(),
            requesterDeviceId = identityManager.deviceId,
            requesterDisplayName = identityManager.displayName,
            requesterPublicKey = identityManager.publicKeyBase64
        )

        val packet = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.PAIR_REQUEST,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = targetPeer.deviceId,
            payloadJson = PacketSerializer.serializePairRequest(payload)
        )

        val signedPacket = PacketSerializer.signPacket(packet, identityManager.privateKey)
        val result = transportClient.sendAndReceive(targetPeer.hostAddress, targetPeer.port, signedPacket)

        return result.mapCatching { responsePacket ->
            if (responsePacket.packetType != PacketType.PAIR_RESPONSE) {
                throw IllegalStateException("Unexpected response type: ${responsePacket.packetType}")
            }
            val response = PacketSerializer.deserializePairResponse(responsePacket.payloadJson)
            if (response.approved) {
                // Save owner device as TRUSTED
                val ownerDevice = Device(
                    deviceId = response.ownerDeviceId,
                    displayName = response.ownerDisplayName,
                    publicKeyBase64 = response.ownerPublicKey,
                    trustState = TrustState.TRUSTED,
                    isOwner = true,
                    lastSeen = System.currentTimeMillis()
                )
                database.deviceDao().insertOrUpdate(ownerDevice)

                // Create conversation
                val conv = Conversation(
                    conversationId = "conv_${response.ownerDeviceId}",
                    peerDeviceId = response.ownerDeviceId,
                    lastMessagePreview = "Pairing approved. Network joined."
                )
                database.conversationDao().insertOrUpdate(conv)
                true
            } else {
                throw IllegalStateException(response.reason ?: "Pairing request was rejected by owner.")
            }
        }
    }

    /**
     * Owner receives a PAIR_REQUEST packet and records it for UI approval.
     */
    suspend fun handleIncomingPairRequest(
        packet: ProtocolPacket,
        respond: (ProtocolPacket) -> Unit
    ) {
        val reqPayload = PacketSerializer.deserializePairRequest(packet.payloadJson)

        // Check if invite code matches active invitation and is not expired
        val activeCode = _activeInviteCode.value
        val expires = _inviteExpiresAt.value ?: 0L
        val isValidCode = activeCode != null &&
                activeCode.equals(reqPayload.inviteCode, ignoreCase = true) &&
                System.currentTimeMillis() <= expires

        if (!isValidCode) {
            val rejectResponse = PairResponsePayload(
                approved = false,
                ownerDeviceId = identityManager.deviceId,
                ownerDisplayName = identityManager.displayName,
                ownerPublicKey = identityManager.publicKeyBase64,
                reason = "Invalid or expired invitation code"
            )
            val respPacket = ProtocolPacket(
                protocolVersion = 1,
                packetType = PacketType.PAIR_RESPONSE,
                packetId = UUID.randomUUID().toString(),
                senderDeviceId = identityManager.deviceId,
                receiverDeviceId = packet.senderDeviceId,
                payloadJson = PacketSerializer.serializePairResponse(rejectResponse)
            )
            respond(PacketSerializer.signPacket(respPacket, identityManager.privateKey))
            return
        }

        // Store request in database for Owner review in UI
        val request = PairingRequest(
            requestId = packet.packetId,
            temporaryCode = reqPayload.inviteCode,
            requesterDeviceId = reqPayload.requesterDeviceId,
            requesterName = reqPayload.requesterDisplayName,
            requesterPublicKey = reqPayload.requesterPublicKey,
            expiresAt = expires,
            status = PairingStatus.ACTIVE
        )
        database.pairingRequestDao().insert(request)

        // Keep peer device in PENDING state
        val pendingDevice = Device(
            deviceId = reqPayload.requesterDeviceId,
            displayName = reqPayload.requesterDisplayName,
            publicKeyBase64 = reqPayload.requesterPublicKey,
            trustState = TrustState.PENDING,
            isOwner = false,
            lastSeen = System.currentTimeMillis()
        )
        database.deviceDao().insertOrUpdate(pendingDevice)
    }

    /**
     * Owner approves a pairing request.
     */
    fun approvePairing(request: PairingRequest, onApproved: (PairResponsePayload) -> Unit) {
        scope.launch(Dispatchers.IO) {
            database.pairingRequestDao().updateStatus(request.requestId, PairingStatus.APPROVED)
            database.deviceDao().updateTrustState(request.requesterDeviceId, TrustState.TRUSTED)

            val conv = Conversation(
                conversationId = "conv_${request.requesterDeviceId}",
                peerDeviceId = request.requesterDeviceId,
                lastMessagePreview = "Device paired successfully."
            )
            database.conversationDao().insertOrUpdate(conv)

            val response = PairResponsePayload(
                approved = true,
                ownerDeviceId = identityManager.deviceId,
                ownerDisplayName = identityManager.displayName,
                ownerPublicKey = identityManager.publicKeyBase64
            )
            onApproved(response)
        }
    }

    /**
     * Owner rejects a pairing request.
     */
    fun rejectPairing(request: PairingRequest, onRejected: (PairResponsePayload) -> Unit) {
        scope.launch(Dispatchers.IO) {
            database.pairingRequestDao().updateStatus(request.requestId, PairingStatus.REJECTED)
            database.deviceDao().updateTrustState(request.requesterDeviceId, TrustState.REVOKED)

            val response = PairResponsePayload(
                approved = false,
                ownerDeviceId = identityManager.deviceId,
                ownerDisplayName = identityManager.displayName,
                ownerPublicKey = identityManager.publicKeyBase64,
                reason = "Owner declined pairing request"
            )
            onRejected(response)
        }
    }
}
