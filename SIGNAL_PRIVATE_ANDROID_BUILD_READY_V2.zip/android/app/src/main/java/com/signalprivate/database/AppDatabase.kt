package com.signalprivate.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.signalprivate.model.Conversation
import com.signalprivate.model.Device
import com.signalprivate.model.Message
import com.signalprivate.model.MessageStatus
import com.signalprivate.model.PairingRequest
import com.signalprivate.model.PairingStatus
import com.signalprivate.model.TrustState

class Converters {
    @TypeConverter
    fun fromTrustState(value: TrustState): String = value.name

    @TypeConverter
    fun toTrustState(value: String): TrustState = TrustState.valueOf(value)

    @TypeConverter
    fun fromMessageStatus(value: MessageStatus): String = value.name

    @TypeConverter
    fun toMessageStatus(value: String): MessageStatus = MessageStatus.valueOf(value)

    @TypeConverter
    fun fromPairingStatus(value: PairingStatus): String = value.name

    @TypeConverter
    fun toPairingStatus(value: String): PairingStatus = PairingStatus.valueOf(value)
}

@Database(
    entities = [
        Device::class,
        Message::class,
        Conversation::class,
        PairingRequest::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deviceDao(): DeviceDao
    abstract fun messageDao(): MessageDao
    abstract fun conversationDao(): ConversationDao
    abstract fun pairingRequestDao(): PairingRequestDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "signal_private.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
