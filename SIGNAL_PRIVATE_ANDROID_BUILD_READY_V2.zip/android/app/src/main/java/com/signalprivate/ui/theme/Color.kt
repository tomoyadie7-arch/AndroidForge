package com.signalprivate.ui.theme

import androidx.compose.ui.graphics.Color

val SignalDarkBackground = Color(0xFF080C13)
val SignalDarkSurface = Color(0xFF0F1722)
val SignalSurfaceElevated = Color(0xFF162334)
val SignalBorder = Color(0xFF1E2B3E)

val SignalCyan = Color(0xFF00E5FF)
val SignalIce = Color(0xFF64FFDA)
val SignalGreen = Color(0xFF26A69A)
val SignalAmber = Color(0xFFFFB300)
val SignalRed = Color(0xFFFF5252)

val SignalTextPrimary = Color(0xFFE6EDF3)
val SignalTextSecondary = Color(0xFF8B949E)
val SignalTextMuted = Color(0xFF484F58)
