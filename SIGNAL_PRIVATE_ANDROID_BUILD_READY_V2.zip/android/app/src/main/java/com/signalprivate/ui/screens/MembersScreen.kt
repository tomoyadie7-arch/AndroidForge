package com.signalprivate.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprivate.model.TrustState
import com.signalprivate.ui.theme.*
import com.signalprivate.ui.viewmodel.SignalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MembersScreen(
    viewModel: SignalViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToAddMember: () -> Unit,
    onNavigateToDeviceDetail: (String) -> Unit
) {
    val members by viewModel.allDevices.collectAsState()
    val pendingRequests by viewModel.pendingPairingRequests.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()

    val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SignalDarkBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = SignalTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "MEMBERS",
                style = MaterialTheme.typography.headlineLarge,
                color = SignalTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Pending Pairing Requests (if any)
        if (pendingRequests.isNotEmpty()) {
            Text(
                text = "PENDING PAIRING REQUESTS",
                style = MaterialTheme.typography.labelSmall,
                color = SignalAmber
            )
            Spacer(modifier = Modifier.height(8.dp))

            pendingRequests.forEach { req ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = SignalDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SignalAmber)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = req.requesterName.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = SignalTextPrimary
                            )
                            Text(
                                text = req.temporaryCode,
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalAmber
                            )
                        }

                        Text(
                            text = "DEVICE: ${req.requesterDeviceId}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SignalTextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.approvePairingRequest(req) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SignalIce,
                                    contentColor = SignalDarkBackground
                                )
                            ) {
                                Text("APPROVE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }

                            Button(
                                onClick = { viewModel.rejectPairingRequest(req) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(4.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SignalSurfaceElevated,
                                    contentColor = SignalRed
                                )
                            ) {
                                Text("REJECT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Trusted Members Section
        Text(
            text = "TRUSTED DEVICES",
            style = MaterialTheme.typography.labelSmall,
            color = SignalTextSecondary
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(members) { dev ->
                val isOnline = discoveredPeers.containsKey(dev.deviceId)
                val isMe = dev.deviceId == viewModel.identityManager.deviceId

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToDeviceDetail(dev.deviceId) },
                    shape = RoundedCornerShape(8.dp),
                    color = SignalDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isOnline || isMe) SignalIce else SignalTextMuted)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (isMe) "${dev.displayName.uppercase()} (YOU)" else dev.displayName.uppercase(),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SignalTextPrimary
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when (dev.trustState) {
                                    TrustState.TRUSTED -> SignalIce.copy(alpha = 0.15f)
                                    TrustState.PENDING -> SignalAmber.copy(alpha = 0.15f)
                                    TrustState.REVOKED -> SignalRed.copy(alpha = 0.15f)
                                }
                            ) {
                                Text(
                                    text = dev.trustState.name,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = when (dev.trustState) {
                                        TrustState.TRUSTED -> SignalIce
                                        TrustState.PENDING -> SignalAmber
                                        TrustState.REVOKED -> SignalRed
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ID: ${dev.deviceId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalTextMuted
                            )
                            Text(
                                text = "LAST SEEN: ${dateFormat.format(Date(dev.lastSeen))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalTextMuted
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ADD MEMBER Button
        Button(
            onClick = onNavigateToAddMember,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(6.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = SignalCyan,
                contentColor = SignalDarkBackground
            )
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                "ADD MEMBER",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}
