package com.signalprivate.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class MessageStatus {
    LOCAL,
    QUEUED,
    SENDING,
    SENT,
    DELIVERED,
    READ,
    FAILED
}

@Entity(
    tableName = "messages",
    indices = [
        Index(value = ["conversationId"]),
        Index(value = ["status"]),
        Index(value = ["createdAt"])
    ]
)
data class Message(
    @PrimaryKey
    val messageId: String,
    val conversationId: String,
    val senderDeviceId: String,
    val receiverDeviceId: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.LOCAL,
    val retryCount: Int = 0,
    val lastAttemptAt: Long = 0L,
    val deliveryTimestamp: Long? = null,
    val readTimestamp: Long? = null
)
