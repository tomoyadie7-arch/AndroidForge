package com.signalprivate.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.util.Log
import com.signalprivate.model.NetworkPeer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.InetAddress

class NsdDiscoveryManager(
    private val context: Context,
    private val myDeviceId: String,
    private val myDisplayName: String,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "SignalNSD"
        const val SERVICE_TYPE = "_signalprivate._tcp."
        const val SERVICE_NAME_PREFIX = "SIGNAL_"
    }

    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager

    private val _discoveredPeers = MutableStateFlow<Map<String, NetworkPeer>>(emptyMap())
    val discoveredPeers: StateFlow<Map<String, NetworkPeer>> = _discoveredPeers.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var registeredServiceName: String? = null

    var onPeerDiscovered: ((NetworkPeer) -> Unit)? = null
    var onPeerLost: ((String) -> Unit)? = null

    /**
     * Advertise this device as a local SIGNAL // PRIVATE node.
     */
    fun registerService(port: Int) {
        if (nsdManager == null) {
            Log.e(TAG, "NsdManager not available on this device")
            return
        }

        val serviceInfo = NsdServiceInfo().apply {
            serviceType = SERVICE_TYPE
            serviceName = "$SERVICE_NAME_PREFIX$myDeviceId"
            setPort(port)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                setAttribute("id", myDeviceId)
                setAttribute("name", myDisplayName)
                setAttribute("ver", "1")
            }
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                registeredServiceName = info.serviceName
                Log.i(TAG, "Service successfully registered on LAN: ${info.serviceName} at port $port")
            }

            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "Service registration failed with code: $errorCode")
            }

            override fun onServiceUnregistered(info: NsdServiceInfo) {
                Log.i(TAG, "Service unregistered: ${info.serviceName}")
            }

            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "Service unregistration failed with code: $errorCode")
            }
        }

        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "Exception during registerService", e)
        }
    }

    /**
     * Start continuous discovery for other SIGNAL // PRIVATE devices on local Wi-Fi / hotspot.
     */
    fun startDiscovery() {
        if (nsdManager == null || _isDiscovering.value) return

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery failed to start: $errorCode")
                _isDiscovering.value = false
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.e(TAG, "Discovery failed to stop: $errorCode")
            }

            override fun onDiscoveryStarted(serviceType: String) {
                Log.i(TAG, "Local service discovery started for $serviceType")
                _isDiscovering.value = true
            }

            override fun onDiscoveryStopped(serviceType: String) {
                Log.i(TAG, "Local service discovery stopped")
                _isDiscovering.value = false
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                Log.d(TAG, "Discovered LAN service candidate: ${serviceInfo.serviceName}")
                if (!serviceInfo.serviceType.contains("signalprivate")) return
                if (serviceInfo.serviceName == registeredServiceName) {
                    // Ignore self advertisement
                    return
                }

                // Resolve service IP and port
                resolveService(serviceInfo)
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                Log.d(TAG, "Service lost on LAN: ${serviceInfo.serviceName}")
                val lostName = serviceInfo.serviceName
                val peerId = if (lostName.startsWith(SERVICE_NAME_PREFIX)) {
                    lostName.removePrefix(SERVICE_NAME_PREFIX)
                } else lostName

                scope.launch(Dispatchers.IO) {
                    val current = _discoveredPeers.value.toMutableMap()
                    current.remove(peerId)
                    _discoveredPeers.value = current
                    onPeerLost?.invoke(peerId)
                }
            }
        }

        try {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "Exception starting discovery", e)
        }
    }

    private fun resolveService(serviceInfo: NsdServiceInfo) {
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                Log.w(TAG, "Resolve failed for ${info.serviceName} with code $errorCode")
            }

            override fun onServiceResolved(info: NsdServiceInfo) {
                val host: InetAddress = info.host ?: return
                val port = info.port
                val hostAddress = host.hostAddress ?: return

                var peerId = info.serviceName.removePrefix(SERVICE_NAME_PREFIX)
                var peerName = peerId

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    val attributes = info.attributes
                    attributes["id"]?.let { peerId = String(it, Charsets.UTF_8) }
                    attributes["name"]?.let { peerName = String(it, Charsets.UTF_8) }
                }

                if (peerId == myDeviceId) return

                val peer = NetworkPeer(
                    deviceId = peerId,
                    displayName = peerName,
                    hostAddress = hostAddress,
                    port = port,
                    lastDiscoveredAt = System.currentTimeMillis()
                )

                scope.launch(Dispatchers.IO) {
                    val current = _discoveredPeers.value.toMutableMap()
                    current[peerId] = peer
                    _discoveredPeers.value = current
                    onPeerDiscovered?.invoke(peer)
                }
            }
        }

        try {
            nsdManager?.resolveService(serviceInfo, resolveListener)
        } catch (e: Exception) {
            Log.w(TAG, "Could not resolve service ${serviceInfo.serviceName}", e)
        }
    }

    fun stopDiscovery() {
        if (!_isDiscovering.value || nsdManager == null) return
        try {
            discoveryListener?.let { nsdManager.stopServiceDiscovery(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping discovery", e)
        } finally {
            discoveryListener = null
            _isDiscovering.value = false
        }
    }

    fun unregisterService() {
        if (registrationListener == null || nsdManager == null) return
        try {
            registrationListener?.let { nsdManager.unregisterService(it) }
        } catch (e: Exception) {
            Log.w(TAG, "Error unregistering service", e)
        } finally {
            registrationListener = null
            registeredServiceName = null
        }
    }

    fun stopAll() {
        stopDiscovery()
        unregisterService()
        _discoveredPeers.value = emptyMap()
    }
}
