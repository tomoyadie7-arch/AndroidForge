package com.signalprivate.security

import android.util.Base64
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.MessageDigest
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedPayload(
    val ciphertextBase64: String,
    val ivBase64: String
)

object CryptoEngine {
    private const val EC_CURVE = "secp256r1"
    private const val SIGNATURE_ALGORITHM = "SHA256withECDSA"
    private const val AES_GCM_ALGORITHM = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128
    private const val GCM_IV_LENGTH = 12 // 96-bit IV recommended for GCM

    private val secureRandom = SecureRandom()

    /**
     * Generates a persistent NIST P-256 (secp256r1) key pair for the device.
     */
    fun generateKeyPair(): KeyPair {
        val keyPairGenerator = KeyPairGenerator.getInstance("EC")
        val ecSpec = ECGenParameterSpec(EC_CURVE)
        keyPairGenerator.initialize(ecSpec, secureRandom)
        return keyPairGenerator.generateKeyPair()
    }

    /**
     * Signs data using ECDSA SHA256.
     */
    fun sign(data: ByteArray, privateKey: PrivateKey): String {
        val signer = Signature.getInstance(SIGNATURE_ALGORITHM)
        signer.initSign(privateKey)
        signer.update(data)
        val signatureBytes = signer.sign()
        return Base64.encodeToString(signatureBytes, Base64.NO_WRAP)
    }

    /**
     * Verifies ECDSA signature using sender's public key.
     */
    fun verify(data: ByteArray, signatureBase64: String, publicKey: PublicKey): Boolean {
        return try {
            val signatureBytes = Base64.decode(signatureBase64, Base64.NO_WRAP)
            val verifier = Signature.getInstance(SIGNATURE_ALGORITHM)
            verifier.initVerify(publicKey)
            verifier.update(data)
            verifier.verify(signatureBytes)
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Derives a shared pairwise AES-256 key between local private key and remote public key via ECDH.
     */
    fun deriveSharedSecret(myPrivateKey: PrivateKey, peerPublicKey: PublicKey): SecretKeySpec {
        val keyAgreement = KeyAgreement.getInstance("ECDH")
        keyAgreement.init(myPrivateKey)
        keyAgreement.doPhase(peerPublicKey, true)
        val sharedSecret = keyAgreement.generateSecret()

        // Derive 256-bit symmetric key using SHA-256 HKDF/hash
        val digest = MessageDigest.getInstance("SHA-256")
        val derivedKey = digest.digest(sharedSecret)
        return SecretKeySpec(derivedKey, "AES")
    }

    /**
     * Encrypts plaintext string using AES-256-GCM.
     */
    fun encrypt(plaintext: String, secretKey: SecretKeySpec): EncryptedPayload {
        val iv = ByteArray(GCM_IV_LENGTH)
        secureRandom.nextBytes(iv)

        val cipher = Cipher.getInstance(AES_GCM_ALGORITHM)
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)

        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return EncryptedPayload(
            ciphertextBase64 = Base64.encodeToString(ciphertext, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        )
    }

    /**
     * Decrypts ciphertext string using AES-256-GCM.
     */
    fun decrypt(encryptedPayload: EncryptedPayload, secretKey: SecretKeySpec): String {
        val iv = Base64.decode(encryptedPayload.ivBase64, Base64.NO_WRAP)
        val ciphertext = Base64.decode(encryptedPayload.ciphertextBase64, Base64.NO_WRAP)

        val cipher = Cipher.getInstance(AES_GCM_ALGORITHM)
        val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
        cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)

        val decryptedBytes = cipher.doFinal(ciphertext)
        return String(decryptedBytes, Charsets.UTF_8)
    }

    fun encodePublicKey(publicKey: PublicKey): String {
        return Base64.encodeToString(publicKey.encoded, Base64.NO_WRAP)
    }

    fun decodePublicKey(base64: String): PublicKey {
        val keyBytes = Base64.decode(base64, Base64.NO_WRAP)
        val spec = X509EncodedKeySpec(keyBytes)
        val keyFactory = KeyFactory.getInstance("EC")
        return keyFactory.generatePublic(spec)
    }

    fun encodePrivateKey(privateKey: PrivateKey): String {
        return Base64.encodeToString(privateKey.encoded, Base64.NO_WRAP)
    }

    fun decodePrivateKey(base64: String): PrivateKey {
        val keyBytes = Base64.decode(base64, Base64.NO_WRAP)
        val spec = PKCS8EncodedKeySpec(keyBytes)
        val keyFactory = KeyFactory.getInstance("EC")
        return keyFactory.generatePrivate(spec)
    }

    /**
     * Generates a 9-character human-friendly invite code e.g. "K7F-29Q-81M".
     */
    fun generateInvitationCode(): String {
        val chars = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ" // Exclude confusing chars 0, 1, I, O
        fun chunk(length: Int): String {
            return (1..length).map { chars[secureRandom.nextInt(chars.length)] }.joinToString("")
        }
        return "${chunk(3)}-${chunk(3)}-${chunk(3)}"
    }

    /**
     * Produces a visual fingerprint of a public key (e.g. for verification).
     */
    fun getFingerprint(publicKeyBase64: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(Base64.decode(publicKeyBase64, Base64.NO_WRAP))
            hash.take(8).joinToString(":") { "%02X".format(it) }
        } catch (e: Exception) {
            "UNKNOWN"
        }
    }
}
