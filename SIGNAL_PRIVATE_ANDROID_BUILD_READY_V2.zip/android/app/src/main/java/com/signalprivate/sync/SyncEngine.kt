package com.signalprivate.sync

import android.util.Log
import com.signalprivate.database.AppDatabase
import com.signalprivate.model.*
import com.signalprivate.network.PacketSerializer
import com.signalprivate.network.TransportClient
import com.signalprivate.security.CryptoEngine
import com.signalprivate.security.IdentityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import java.util.UUID

class SyncEngine(
    private val database: AppDatabase,
    private val identityManager: IdentityManager,
    private val transportClient: TransportClient,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "SignalSync"
    }

    private val _eventLogs = MutableSharedFlow<NetworkEventLog>(replay = 50)
    val eventLogs: SharedFlow<NetworkEventLog> = _eventLogs.asSharedFlow()

    private fun logEvent(message: String) {
        val event = NetworkEventLog(System.currentTimeMillis(), message)
        scope.launch {
            _eventLogs.emit(event)
        }
        Log.i(TAG, message)
    }

    /**
     * Executes full 2-way sync with a discovered peer:
     * 1. Authenticate peer trust
     * 2. Send SYNC_REQUEST with local known IDs
     * 3. Receive missing messages and persist into Room
     * 4. Reverse sync (send messages remote peer is missing)
     */
    suspend fun synchronizeWithPeer(peer: NetworkPeer): Result<Int> {
        val device = database.deviceDao().getDeviceById(peer.deviceId)
        if (device == null || device.trustState != TrustState.TRUSTED) {
            logEvent("Sync skipped: Peer ${peer.displayName} is not a trusted device.")
            return Result.failure(IllegalStateException("Peer is not trusted"))
        }

        logEvent("${peer.displayName} discovered on local network")
        logEvent("Trust verified for ${peer.displayName}")
        logEvent("Synchronization started with ${peer.displayName}")

        val conversation = database.conversationDao().getConversationForPeer(peer.deviceId)
            ?: run {
                val newConv = Conversation(
                    conversationId = "conv_${peer.deviceId}",
                    peerDeviceId = peer.deviceId
                )
                database.conversationDao().insertOrUpdate(newConv)
                newConv
            }

        // 1. Gather all local message IDs for this conversation
        val localMessageIds = database.messageDao().getMessageIdsForConversation(conversation.conversationId)

        // 2. Prepare SYNC_REQUEST packet
        val syncReqPayload = SyncRequestPayload(
            senderDeviceId = identityManager.deviceId,
            knownMessageIds = localMessageIds
        )
        val packet = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.SYNC_REQUEST,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = peer.deviceId,
            payloadJson = PacketSerializer.serializeSyncRequest(syncReqPayload)
        )

        val signedPacket = PacketSerializer.signPacket(packet, identityManager.privateKey)
        val result = transportClient.sendAndReceive(peer.hostAddress, peer.port, signedPacket)

        return result.mapCatching { responsePacket ->
            if (responsePacket.packetType != PacketType.SYNC_RESPONSE) {
                throw IllegalStateException("Unexpected sync response type: ${responsePacket.packetType}")
            }

            val syncResponse = PacketSerializer.deserializeSyncResponse(responsePacket.payloadJson)
            val peerPubKey = CryptoEngine.decodePublicKey(device.publicKeyBase64)
            val sharedKey = CryptoEngine.deriveSharedSecret(identityManager.privateKey, peerPubKey)

            var importedCount = 0
            for (item in syncResponse.messages) {
                // Decrypt message body
                val decryptedBody = try {
                    CryptoEngine.decrypt(
                        com.signalprivate.security.EncryptedPayload(item.encryptedBody, item.ivBase64),
                        sharedKey
                    )
                } catch (e: Exception) {
                    "[Encrypted message]"
                }

                val message = Message(
                    messageId = item.messageId,
                    conversationId = conversation.conversationId,
                    senderDeviceId = item.senderDeviceId,
                    receiverDeviceId = item.receiverDeviceId,
                    body = decryptedBody,
                    createdAt = item.timestamp,
                    status = if (item.senderDeviceId == identityManager.deviceId) MessageStatus.SENT else MessageStatus.DELIVERED
                )

                val rowId = database.messageDao().insertMessage(message)
                if (rowId != -1L) {
                    importedCount++
                }
            }

            // Update conversation last message preview
            if (syncResponse.messages.isNotEmpty()) {
                val latest = syncResponse.messages.maxByOrNull { it.timestamp }
                if (latest != null) {
                    database.conversationDao().updateLastMessage(
                        conversation.conversationId,
                        latest.timestamp,
                        "Synchronized ${syncResponse.messages.size} messages"
                    )
                }
            }

            database.deviceDao().updateLastSeen(peer.deviceId, System.currentTimeMillis())
            logEvent("$importedCount messages synchronized with ${peer.displayName}")
            logEvent("Sync complete")
            importedCount
        }
    }

    /**
     * Handles incoming SYNC_REQUEST: responds with messages that the remote peer doesn't have.
     */
    suspend fun handleSyncRequest(packet: ProtocolPacket, respond: (ProtocolPacket) -> Unit) {
        val req = PacketSerializer.deserializeSyncRequest(packet.payloadJson)
        val remoteKnownSet = req.knownMessageIds.toSet()

        val peerDevice = database.deviceDao().getDeviceById(packet.senderDeviceId)
        if (peerDevice == null || peerDevice.trustState != TrustState.TRUSTED) {
            logEvent("Rejected sync request from untrusted device ${packet.senderDeviceId}")
            return
        }

        val conv = database.conversationDao().getConversationForPeer(packet.senderDeviceId)
        val convId = conv?.conversationId ?: "conv_${packet.senderDeviceId}"
        val allLocalMessages = database.messageDao().getRecentMessages(convId, 200)

        val peerPubKey = CryptoEngine.decodePublicKey(peerDevice.publicKeyBase64)
        val sharedKey = CryptoEngine.deriveSharedSecret(identityManager.privateKey, peerPubKey)

        val missingForRemote = allLocalMessages.filter { it.messageId !in remoteKnownSet }
        val transferList = missingForRemote.map { msg ->
            val enc = CryptoEngine.encrypt(msg.body, sharedKey)
            MessageTransferItem(
                messageId = msg.messageId,
                conversationId = msg.conversationId,
                senderDeviceId = msg.senderDeviceId,
                receiverDeviceId = msg.receiverDeviceId,
                encryptedBody = enc.ciphertextBase64,
                ivBase64 = enc.ivBase64,
                timestamp = msg.createdAt,
                status = msg.status.name
            )
        }

        val responsePayload = SyncResponsePayload(
            senderDeviceId = identityManager.deviceId,
            messages = transferList
        )

        val respPacket = ProtocolPacket(
            protocolVersion = 1,
            packetType = PacketType.SYNC_RESPONSE,
            packetId = UUID.randomUUID().toString(),
            senderDeviceId = identityManager.deviceId,
            receiverDeviceId = packet.senderDeviceId,
            payloadJson = PacketSerializer.serializeSyncResponse(responsePayload)
        )

        respond(PacketSerializer.signPacket(respPacket, identityManager.privateKey))
    }
}
