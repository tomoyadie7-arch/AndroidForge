package com.signalprivate.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.util.Log
import com.signalprivate.model.InternetConnectivity
import com.signalprivate.model.LocalNetworkConnectivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.Inet4Address
import java.net.NetworkInterface

class NetworkMonitor(private val context: Context) {
    companion object {
        private const val TAG = "SignalNetMonitor"
    }

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _internetStatus = MutableStateFlow(InternetConnectivity.OFFLINE)
    val internetStatus: StateFlow<InternetConnectivity> = _internetStatus.asStateFlow()

    private val _localNetworkStatus = MutableStateFlow(LocalNetworkConnectivity.DISCONNECTED)
    val localNetworkStatus: StateFlow<LocalNetworkConnectivity> = _localNetworkStatus.asStateFlow()

    private val _localIpAddress = MutableStateFlow<String?>(null)
    val localIpAddress: StateFlow<String?> = _localIpAddress.asStateFlow()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            updateNetworkState()
        }

        override fun onLost(network: Network) {
            updateNetworkState()
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            updateNetworkState()
        }
    }

    fun start() {
        updateNetworkState()
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
            .build()
        try {
            connectivityManager?.registerNetworkCallback(request, networkCallback)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register network callback", e)
        }
    }

    fun stop() {
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun updateNetworkState() {
        val cm = connectivityManager ?: return
        val activeNetwork = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(activeNetwork)

        // Internet check (validation by Android)
        val hasInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

        _internetStatus.value = if (hasInternet) InternetConnectivity.ONLINE else InternetConnectivity.OFFLINE

        // Local Network check: check if any local Wi-Fi / hotspot / LAN IP is bound
        val localIp = findLocalIpAddress()
        _localIpAddress.value = localIp

        val isLocalConnected = localIp != null ||
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

        _localNetworkStatus.value = if (isLocalConnected) {
            LocalNetworkConnectivity.CONNECTED
        } else {
            LocalNetworkConnectivity.DISCONNECTED
        }

        Log.d(TAG, "Network updated: Internet=${_internetStatus.value}, Local=${_localNetworkStatus.value}, IP=$localIp")
    }

    /**
     * Resolves the primary local IPv4 address (e.g. 192.168.x.x, 10.x.x.x, 172.16-31.x.x)
     */
    fun findLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (intf in interfaces) {
                if (intf.isLoopback || !intf.isUp) continue
                val addrs = intf.inetAddresses
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress
                        if (host != null && !host.startsWith("127.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not obtain local IP address", e)
        }
        return null
    }
}
