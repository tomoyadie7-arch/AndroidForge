package com.signalprivate

import android.app.Application
import android.util.Log
import com.signalprivate.database.AppDatabase
import com.signalprivate.model.Device
import com.signalprivate.model.TrustState
import com.signalprivate.repository.SignalRepository
import com.signalprivate.security.IdentityManager
import com.signalprivate.service.SignalLocalService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class SignalApplication : Application() {
    companion object {
        lateinit var instance: SignalApplication
            private set
    }

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var database: AppDatabase
    lateinit var identityManager: IdentityManager
    lateinit var repository: SignalRepository

    override fun onCreate() {
        super.onCreate()
        instance = this

        Log.i("SignalApp", "Initializing SIGNAL // PRIVATE application...")

        database = AppDatabase.getInstance(this)
        identityManager = IdentityManager(this)
        repository = SignalRepository(this, database, identityManager, appScope)

        // Seed initial device owner record if not present
        appScope.launch(Dispatchers.IO) {
            val self = database.deviceDao().getDeviceById(identityManager.deviceId)
            if (self == null) {
                val selfDevice = Device(
                    deviceId = identityManager.deviceId,
                    displayName = identityManager.displayName,
                    publicKeyBase64 = identityManager.publicKeyBase64,
                    trustState = TrustState.TRUSTED,
                    isOwner = identityManager.isOwner
                )
                database.deviceDao().insertOrUpdate(selfDevice)
            }
        }

        // Start network stack
        repository.start()

        // Start foreground service for lifecycle resiliency
        try {
            SignalLocalService.start(this)
        } catch (e: Exception) {
            Log.w("SignalApp", "Could not start foreground service yet", e)
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        repository.stop()
    }
}
