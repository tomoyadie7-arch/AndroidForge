package com.signalprivate.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprivate.model.Message
import com.signalprivate.model.MessageStatus
import com.signalprivate.ui.theme.*
import com.signalprivate.ui.viewmodel.SignalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ChatScreen(
    peerDeviceId: String,
    viewModel: SignalViewModel,
    onNavigateBack: () -> Unit
) {
    val members by viewModel.allDevices.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()

    val peerDevice = members.find { it.deviceId == peerDeviceId }
    val isPeerOnline = discoveredPeers.containsKey(peerDeviceId)

    val convId = "conv_$peerDeviceId"
    val messagesFlow = remember(convId) { viewModel.getMessagesForConversation(convId) }
    val messages by messagesFlow.collectAsState(initial = emptyList())

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Send read receipts when conversation is active
    LaunchedEffect(convId, peerDeviceId) {
        viewModel.markConversationRead(convId, peerDeviceId)
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SignalDarkBackground)
            .statusBarsPadding()
            .imePadding()
    ) {
        // Chat Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = SignalTextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isPeerOnline) SignalIce else SignalTextMuted)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = peerDevice?.displayName?.uppercase() ?: peerDeviceId,
                        style = MaterialTheme.typography.titleMedium,
                        color = SignalTextPrimary
                    )
                    Text(
                        text = if (isPeerOnline) "● LOCAL CONNECTION" else "LOCAL PEER OFFLINE",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isPeerOnline) SignalIce else SignalAmber
                    )
                }
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SignalDarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "ENCRYPTED LOCAL CHANNEL",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SignalCyan
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Direct peer-to-peer encryption • No intermediate server",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SignalTextMuted
                                )
                            }
                        }
                    }
                }
            }

            items(messages, key = { it.messageId }) { msg ->
                val isOutgoing = msg.senderDeviceId == viewModel.identityManager.deviceId
                MessageBubble(message = msg, isOutgoing = isOutgoing)
            }
        }

        // Offline Banner Alert if peer is offline
        if (!isPeerOnline) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SignalSurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PEER OFFLINE • Messages will queue and auto-sync on local connection",
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalAmber,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Message Composer
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = {
                        Text(
                            text = if (isPeerOnline) "Write message..." else "Type message (will queue)...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SignalTextMuted
                        )
                    },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedTextColor = SignalTextPrimary,
                        unfocusedTextColor = SignalTextPrimary,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    maxLines = 4
                )

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            viewModel.sendMessage(peerDeviceId, textInput)
                            textInput = ""
                        }
                    },
                    enabled = textInput.isNotBlank(),
                    colors = IconButtonDefaults.iconButtonColors(
                        contentColor = SignalCyan,
                        disabledContentColor = SignalTextMuted
                    )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send"
                    )
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: Message,
    isOutgoing: Boolean
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val timeStr = remember(message.createdAt) { timeFormat.format(Date(message.createdAt)) }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isOutgoing) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 8.dp,
                topEnd = 8.dp,
                bottomStart = if (isOutgoing) 8.dp else 2.dp,
                bottomEnd = if (isOutgoing) 2.dp else 8.dp
            ),
            color = if (isOutgoing) SignalSurfaceElevated else SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isOutgoing) SignalCyan.copy(alpha = 0.3f) else SignalBorder
            ),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    text = message.body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SignalTextPrimary
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalTextMuted,
                        fontSize = 9.sp
                    )

                    if (isOutgoing) {
                        Spacer(modifier = Modifier.width(6.dp))
                        val (statusText, statusColor) = when (message.status) {
                            MessageStatus.QUEUED -> "QUEUED" to SignalAmber
                            MessageStatus.SENDING -> "SENDING" to SignalCyan
                            MessageStatus.SENT -> "✓ SENT" to SignalTextSecondary
                            MessageStatus.DELIVERED -> "✓ DELIVERED" to SignalIce
                            MessageStatus.READ -> "✓ READ" to SignalCyan
                            MessageStatus.LOCAL -> "LOCAL" to SignalTextMuted
                            MessageStatus.FAILED -> "FAILED" to SignalRed
                        }

                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
