package com.signalprivate.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.signalprivate.model.Conversation
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageAt DESC")
    fun getAllConversationsFlow(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE conversationId = :id LIMIT 1")
    suspend fun getConversationById(id: String): Conversation?

    @Query("SELECT * FROM conversations WHERE peerDeviceId = :peerDeviceId LIMIT 1")
    suspend fun getConversationForPeer(peerDeviceId: String): Conversation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(conversation: Conversation)

    @Update
    suspend fun update(conversation: Conversation)

    @Query("UPDATE conversations SET lastMessageAt = :timestamp, lastMessagePreview = :preview WHERE conversationId = :id")
    suspend fun updateLastMessage(id: String, timestamp: Long, preview: String)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE conversationId = :id")
    suspend fun resetUnreadCount(id: String)

    @Query("UPDATE conversations SET unreadCount = unreadCount + 1 WHERE conversationId = :id")
    suspend fun incrementUnreadCount(id: String)
}
