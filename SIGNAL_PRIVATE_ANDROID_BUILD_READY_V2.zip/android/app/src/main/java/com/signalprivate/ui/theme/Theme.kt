package com.signalprivate.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SignalCyan,
    secondary = SignalIce,
    tertiary = SignalGreen,
    background = SignalDarkBackground,
    surface = SignalDarkSurface,
    surfaceVariant = SignalSurfaceElevated,
    onPrimary = SignalDarkBackground,
    onSecondary = SignalDarkBackground,
    onBackground = SignalTextPrimary,
    onSurface = SignalTextPrimary,
    outline = SignalBorder
)

@Composable
fun SignalPrivateTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
