package com.signalprivate.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.signalprivate.ui.theme.*
import com.signalprivate.ui.viewmodel.SignalViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AddMemberScreen(
    viewModel: SignalViewModel,
    onNavigateBack: () -> Unit
) {
    val activeCode by viewModel.activeInviteCode.collectAsState()
    val expiresAt by viewModel.inviteExpiresAt.collectAsState()
    val discoveredPeers by viewModel.discoveredPeers.collectAsState()

    var joinCodeInput by remember { mutableStateOf("") }
    var selectedPeerId by remember { mutableStateOf<String?>(null) }
    var joinStatusMessage by remember { mutableStateOf<String?>(null) }
    var isJoining by remember { mutableStateOf(false) }

    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SignalDarkBackground)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = SignalTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "ADD MEMBER",
                style = MaterialTheme.typography.headlineLarge,
                color = SignalTextPrimary
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 1: OWNER GENERATE INVITATION
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "CREATE INVITATION",
                    style = MaterialTheme.typography.titleMedium,
                    color = SignalCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Generates a 10-minute temporary code to securely pair a new phone on this Wi-Fi network.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SignalTextSecondary
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (activeCode != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        color = SignalSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SignalCyan.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = activeCode!!,
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontSize = 28.sp,
                                    letterSpacing = 3.sp
                                ),
                                color = SignalCyan,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "EXPIRES: ${timeFormat.format(Date(expiresAt ?: System.currentTimeMillis()))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalAmber
                            )
                        }
                    }
                } else {
                    Button(
                        onClick = { viewModel.generateInvitation() },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SignalCyan,
                            contentColor = SignalDarkBackground
                        )
                    ) {
                        Text("GENERATE INVITATION", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SECTION 2: JOIN PRIVATE NETWORK (New device perspective)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            color = SignalDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SignalBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "JOIN PRIVATE NETWORK",
                    style = MaterialTheme.typography.titleMedium,
                    color = SignalIce
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "If another phone generated an invite code, enter it below to request trusted membership.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SignalTextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = joinCodeInput,
                    onValueChange = { joinCodeInput = it.uppercase() },
                    placeholder = {
                        Text(
                            "e.g. K7F-29Q-81M",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SignalTextMuted
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(6.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SignalIce,
                        unfocusedBorderColor = SignalBorder,
                        focusedTextColor = SignalTextPrimary,
                        unfocusedTextColor = SignalTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Select target peer
                Text(
                    text = "TARGET LAN NODE",
                    style = MaterialTheme.typography.labelSmall,
                    color = SignalTextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))

                if (discoveredPeers.isEmpty()) {
                    Text(
                        text = "Searching for nearby SIGNAL nodes on Wi-Fi...",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalTextMuted
                    )
                } else {
                    discoveredPeers.values.forEach { peer ->
                        val isSelected = selectedPeerId == peer.deviceId || selectedPeerId == null
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { selectedPeerId = peer.deviceId },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedPeerId == peer.deviceId) SignalSurfaceElevated else SignalDarkBackground,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (selectedPeerId == peer.deviceId) SignalIce else SignalBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = peer.displayName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SignalTextPrimary
                                )
                                Text(
                                    text = "${peer.hostAddress}:${peer.port}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SignalTextMuted
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val target = discoveredPeers[selectedPeerId] ?: discoveredPeers.values.firstOrNull()
                        if (target != null && joinCodeInput.isNotBlank()) {
                            isJoining = true
                            joinStatusMessage = "Transmitting pairing request over LAN..."
                            viewModel.joinNetwork(target, joinCodeInput) { success, error ->
                                isJoining = false
                                if (success) {
                                    joinStatusMessage = "Pairing approved! Joined network."
                                } else {
                                    joinStatusMessage = "Failed: ${error ?: "Pairing rejected"}"
                                }
                            }
                        } else {
                            joinStatusMessage = "Please select a target LAN peer and enter the code."
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isJoining && joinCodeInput.isNotBlank() && discoveredPeers.isNotEmpty(),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SignalIce,
                        contentColor = SignalDarkBackground,
                        disabledContainerColor = SignalSurfaceElevated
                    )
                ) {
                    Text("JOIN", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (joinStatusMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = joinStatusMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (joinStatusMessage!!.contains("approved")) SignalIce else SignalAmber
                    )
                }
            }
        }
    }
}
