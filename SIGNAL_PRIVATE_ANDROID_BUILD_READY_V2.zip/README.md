# SIGNAL // PRIVATE

> **Private, local-first messaging application for trusted peer devices over local Wi-Fi and hotspots with zero internet dependency.**

---

## 1. Overview & Core Philosophy

**SIGNAL // PRIVATE** is a native Android communication utility designed for a small group of trusted people (such as a family, household, or emergency tactical unit).

It intentionally rejects the public social media model:
- **No public accounts or user lookup directories**
- **No public servers, cloud infrastructure, or Firebase**
- **No online strangers or unsolicited invites**
- **Zero internet access required**

Communication exists **exclusively between manually approved, cryptographically paired Android devices** connected to the same local Wi-Fi router or phone hotspot.

---

## 2. Network Model & Offline-First Operation

### The Tri-State Network Distinction
Standard chat apps confuse "Network Connection" with "Internet Connection". SIGNAL // PRIVATE explicitly separates:
1. **INTERNET**: Validated connection to the global World Wide Web (`ONLINE` / `OFFLINE`).
2. **LOCAL NETWORK**: Active link on a local subnet (`CONNECTED` / `DISCONNECTED`).
3. **SIGNAL**: Active local peer discovery & mesh service (`ONLINE` / `OFFLINE`).

When an ISP cable is cut or devices are out in the wilderness with a portable battery-powered router or mobile hotspot:
```
INTERNET:      OFFLINE
LOCAL NETWORK: CONNECTED
SIGNAL:        ONLINE
```
Messaging remains **100% operational**.

### Transport Modes
1. **Local Wi-Fi Router (No WAN)**: Multiple Android phones connect to any common Wi-Fi access point (even without an active modem or ISP uplink).
2. **Android Wi-Fi Hotspot**: Phone A enables Android Hotspot (cellular data can be OFF). Phone B, C, D connect to Phone A's hotspot Wi-Fi. All phones discover each other and exchange encrypted traffic.

---

## 3. Architecture & Tech Stack

Built following modern Android architectural standards:

```
UI (Jetpack Compose + Material 3 Dark Palette)
       │
ViewModel (SignalViewModel + StateFlow)
       │
SignalRepository (Central Orchestrator)
  ├── Room Database (AppDatabase: Devices, Messages, Conversations, PairingRequests)
  ├── IdentityManager (NIST P-256 ECDSA Keys + Persistent Device Identity)
  ├── NsdDiscoveryManager (Android Network Service Discovery / DNS-SD `_signalprivate._tcp`)
  ├── TransportServer & TransportClient (Framed TCP Sockets on port 42424)
  ├── PairingManager (10-minute time-bound invite codes + Owner ACL)
  ├── OfflineQueueManager (Room-backed offline queue + exponential backoff)
  └── SyncEngine (Idempotent 2-way delta message synchronization)
```

- **Language**: Kotlin 2.0.20
- **UI Toolkit**: Jetpack Compose (Declarative, reactive, dark technical aesthetic)
- **Local Storage**: AndroidX Room 2.6.1 with KSP
- **Concurrency**: Kotlin Coroutines & `StateFlow` / `SharedFlow`
- **Peer Discovery**: Android Network Service Discovery (`NsdManager` DNS-SD)
- **Transport**: Reliable length-prefixed TCP socket framing over LAN
- **Cryptography**: NIST P-256 (secp256r1) ECDSA signatures, ECDH key agreement, AES-256-GCM authenticated payload encryption.

---

## 4. Trusted Device Pairing Model

A new device **never** joins automatically merely by being on the same Wi-Fi.

1. **Owner Device**:
   - Taps `ADD MEMBER` -> `GENERATE INVITATION`.
   - The app cryptographically generates an ephemeral 9-character code (e.g., `K7F-29Q-81M`) valid for **10 minutes**.
2. **New Member Device**:
   - Selects the Owner node discovered on LAN.
   - Enters `K7F-29Q-81M` and taps `JOIN`.
   - Sends a signed `PAIR_REQUEST` containing its display name, unique device ID, and public key.
3. **Owner Review**:
   - The Owner receives an alert: `NEW DEVICE REQUEST: OLIVER (DEVICE-7F29)`.
   - Owner taps `APPROVE` or `REJECT`.
4. **Trust Establishment**:
   - Upon approval, both devices persist the peer's public key in Room with status `TRUSTED`.
   - Both devices derive a pairwise shared secret via ECDH.
   - Any packet from an unknown or revoked device is rejected at the socket boundary.

---

## 5. Message Lifecycle & Offline Queue

Every message undergoes an explicit state progression tracked in Room:

```
[User writes message]
         │
         ▼
     [LOCAL]
         │
    Is peer online?
    ├── YES ──► [SENDING] ──► [✓ SENT] ──(Remote ACK)──► [✓ DELIVERED] ──(Peer reads)──► [✓ READ]
    │
    └── NO  ──► [QUEUED] (Persisted in Room SQLite)
                    │
           (Peer reconnects to Wi-Fi)
                    │
                    ▼
           [LOCAL PEER FOUND]
                    │
                    ▼
                [SYNCING] ──► [✓ DELIVERED]
```

- **Persistence**: If the app is killed, the phone is rebooted, or the Wi-Fi drops, queued messages remain safe in Room.
- **Auto-Sync**: As soon as `NsdDiscoveryManager` resolves the peer on the local subnet, `OfflineQueueManager` drains the queue and `SyncEngine` executes two-way delta synchronization.

---

## 6. How to Build & Install

### Requirements
- Android Studio Iguana / Jellyfish / Koala (2024+)
- JDK 17
- Android SDK 34 (Android 14) with minimum SDK 26 (Android 8.0)

### Steps
1. Clone or open the repository in Android Studio:
   ```bash
   cd android
   ./gradlew assembleDebug
   ```
2. The debug APK will be generated at:
   `android/app/build/outputs/apk/debug/app-debug.apk`
3. Install to device via ADB:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 7. How to Test Using Two Real Android Phones

1. **Prepare the Network**:
   - **Method A (No Internet Router)**: Unplug the WAN/cable from your home Wi-Fi router. Connect Phone A and Phone B to the Wi-Fi.
   - **Method B (Hotspot)**: On Phone A, turn on **Personal Hotspot**. Connect Phone B to Phone A's hotspot. Disable cellular data on both phones.
2. **Launch App on Phone A**:
   - Check the top status bar:
     - `INTERNET: OFFLINE`
     - `LOCAL NETWORK: CONNECTED`
     - `SIGNAL: ONLINE`
   - Notice Phone A is the initial OWNER.
3. **Pair Phone B**:
   - On Phone A: Go to `MANAGE MEMBERS` -> `ADD MEMBER` -> tap `GENERATE INVITATION`. Note the code (e.g. `K7F-29Q-81M`).
   - On Phone B: Go to `ADD MEMBER` -> Enter `K7F-29Q-81M` and select Phone A. Tap `JOIN`.
   - On Phone A: A notification card appears `NEW PAIRING REQUEST`. Tap `APPROVE`.
4. **Test Real-Time Messaging**:
   - On Phone A: Open chat with Phone B. Type "Hello from Phone A".
   - Notice status instantly changes: `SENDING` -> `✓ SENT` -> `✓ DELIVERED`.
   - On Phone B: Open the chat. Phone A's status changes to `✓ READ`.
5. **Test Offline Queueing**:
   - Turn OFF Wi-Fi on Phone B (or put Phone B into Airplane Mode).
   - Phone A's header updates: `LOCAL PEER OFFLINE`.
   - On Phone A, send: "Are you still there?".
   - Status remains: `QUEUED`.
   - Turn Wi-Fi back ON on Phone B.
   - Within 2-3 seconds, Phone A logs `OLIVER discovered` -> `Synchronization started` -> `Sync complete`.
   - The queued message is delivered to Phone B and marked `✓ DELIVERED` on Phone A!

---

## 8. Known Limitations & Technical Decisions
- **Multicast across some enterprise APs**: Certain corporate Wi-Fi networks enable "Client Isolation" which blocks peer-to-peer multicast or direct socket connections between clients. Standard home routers and phone hotspots allow full client-to-client communication.
- **Port Allocation**: Default TCP port is `42424`. If port 42424 is in use, fallback to ephemeral port is handled dynamically and advertised over NSD attributes.
- **Background Execution**: Background synchronization is kept alive via an Android Foreground Service with type `connectedDevice`.
