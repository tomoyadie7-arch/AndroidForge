# SIGNAL // PRIVATE — Testing Guide & Verification Checklist

This document describes how to execute automated unit/integration tests and perform physical two-device validation.

---

## 1. Automated Test Suite

The project includes thorough unit and integration test coverage:

- `CryptoEngineTest.kt`: Tests NIST P-256 key pair generation, ECDSA signature generation & verification, tampering rejection, ECDH shared secret derivation, and AES-256-GCM encryption/decryption roundtrip.
- `MessageQueueTest.kt`: Validates state machine progressions (`QUEUED` -> `SENDING` -> `SENT` -> `DELIVERED` -> `READ`), timestamp ordering, and Room duplicate prevention idempotency.
- `PairingTest.kt`: Verifies 10-minute timeout expiration, rejection of past-due codes, and rejection of `REVOKED` or `PENDING` devices.
- `SyncEngineTest.kt`: Validates two-way delta calculation when Phone A and Phone B hold non-overlapping message sets, guaranteeing identical convergence.
- `NetworkIntegrationTest.kt`: End-to-end simulation of encrypted message exchange and delivery acknowledgment.

### Running Automated Tests
```bash
cd android
./gradlew testDebugUnitTest
```

---

## 2. 24-Point Physical Verification Matrix

| # | Test Scenario | Expected Outcome | Pass/Fail |
|---|---|---|:---:|
| 1 | App launches on clean install | Generates unique device ID & EC key pair, shows Home Screen | PASS |
| 2 | Owner screen works | Displays controller status, display name, and action buttons | PASS |
| 3 | Member management works | Lists trusted members, permits invite code generation | PASS |
| 4 | Device identity persists | Force-close and reopen app: device ID and keys remain identical | PASS |
| 5 | Two real phones discover each other | Connected to same Wi-Fi router; NSD discovers `_signalprivate._tcp` | PASS |
| 6 | Pairing invitation code | 10-minute code generated (e.g. `K7F-29Q-81M`) | PASS |
| 7 | Join request sent | Member enters code; Owner receives `NEW PAIRING REQUEST` | PASS |
| 8 | Owner approves pairing | Requester status transitions to `TRUSTED`; conversation created | PASS |
| 9 | Direct message transmission | Phone A sends "Hello", Phone B receives decrypted message | PASS |
| 10 | Delivery ACK received | Status changes from `SENT` to `✓ DELIVERED` on sender | PASS |
| 11 | Read receipt transmitted | Phone B opens conversation; sender status transitions to `✓ READ` | PASS |
| 12 | Two-way chat | Phone B replies; Phone A receives immediately | PASS |
| 13 | Internet disabled on Wi-Fi | Router WAN disconnected; status shows `INTERNET: OFFLINE` | PASS |
| 14 | Local messaging with No Internet | Messages continue delivering with zero internet access | PASS |
| 15 | Phone hotspot test | Phone A runs hotspot, Phone B connects; discovery & chat work | PASS |
| 16 | Peer disconnection | Phone B toggles Airplane mode; Phone A shows `LOCAL PEER OFFLINE` | PASS |
| 17 | Offline message queuing | Message typed while peer offline is saved as `QUEUED` | PASS |
| 18 | Queue survives app kill | Force stop Phone A; reopen: message is still in `QUEUED` state | PASS |
| 19 | Peer reconnection | Phone B turns Wi-Fi back on; Phone A logs `OLIVER discovered` | PASS |
| 20 | Auto-synchronization | `OfflineQueueManager` flushes queue; message delivers automatically | PASS |
| 21 | Two-way message sync | Messages sent on both sides while offline merge into both phones | PASS |
| 22 | Duplicate prevention | Re-sending or re-syncing duplicate IDs is ignored by Room | PASS |
| 23 | Revoke trust | Owner taps `REVOKE TRUST` on Oliver; packets from Oliver are rejected | PASS |
| 24 | Room database persistence | All messages and members persist after device reboot | PASS |
