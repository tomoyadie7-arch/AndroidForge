# SIGNAL // PRIVATE — Network & Transport Protocol Specification

**Protocol Version**: `1`  
**Default Port**: `42424 / TCP`  
**Discovery Service**: `_signalprivate._tcp.`  

---

## 1. Transport Framing Layer

All packets transmitted over TCP use length-prefixed framing to guarantee boundary isolation and eliminate stream fragmentation issues.

```
+------------------------------------+------------------------------------------+
| 4 Bytes (Big-Endian UInt32)        | N Bytes (UTF-8 Encoded JSON Packet)      |
| Length of Payload (N <= 10MB)      |                                          |
+------------------------------------+------------------------------------------+
```

---

## 2. Common Wire Packet Structure

Every packet adheres to this schema:

```json
{
  "v": 1,
  "type": "MESSAGE",
  "id": "18f8e58a-3677-4b72-b5b9-123456789abc",
  "from": "DEVICE-7F29",
  "to": "DEVICE-A1B2",
  "ts": 1700000000000,
  "payload": "{ ... serialized payload JSON ... }",
  "sig": "MEQCIGs1...Base64ECDSA..."
}
```

### Signature Canonicalization Rule
The digital signature is generated over the canonical UTF-8 byte stream:
```
canonicalString = v + "|" + type + "|" + id + "|" + from + "|" + to + "|" + ts + "|" + payload
signature = ECDSA_Sign(SHA256(canonicalString), senderPrivateKey)
```

---

## 3. Packet Types & Payload Specifications

### 3.1 `HELLO` & `HELLO_ACK`
Exchanged during initial discovery connection:
```json
{
  "deviceId": "DEVICE-7F29",
  "displayName": "NICK",
  "publicKey": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE...",
  "v": 1
}
```

### 3.2 `PAIR_REQUEST`
Sent by a new device attempting to join the private mesh:
```json
{
  "inviteCode": "K7F-29Q-81M",
  "deviceId": "DEVICE-B4E2",
  "displayName": "OLIVER",
  "publicKey": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE..."
}
```

### 3.3 `PAIR_RESPONSE`
Sent by the owner after reviewing the request:
```json
{
  "approved": true,
  "ownerDeviceId": "DEVICE-7F29",
  "ownerDisplayName": "NICK",
  "ownerPublicKey": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE...",
  "reason": ""
}
```

### 3.4 `MESSAGE`
Transfers encrypted message body between paired peers:
```json
{
  "id": "msg_987654321",
  "convId": "conv_DEVICE-B4E2",
  "sender": "DEVICE-7F29",
  "receiver": "DEVICE-B4E2",
  "cipher": "4vT8k/d1M9qZ...ciphertext...",
  "iv": "3f82hK9d821B",
  "ts": 1700000005000
}
```

### 3.5 `MESSAGE_ACK`
Acknowledges physical disk persistence on the recipient's phone (transitions message state from `SENT` to `DELIVERED`):
```json
{
  "id": "msg_987654321",
  "receiver": "DEVICE-B4E2",
  "ts": 1700000006200
}
```

### 3.6 `READ_RECEIPT`
Sent when the conversation view is opened:
```json
{
  "id": "msg_987654321",
  "convId": "conv_DEVICE-B4E2",
  "reader": "DEVICE-B4E2",
  "ts": 1700000010000
}
```

### 3.7 `SYNC_REQUEST` & `SYNC_RESPONSE`
Allows offline queue recovery and multi-message reconciliation:
```json
// SYNC_REQUEST
{
  "deviceId": "DEVICE-7F29",
  "knownIds": ["msg_1", "msg_2", "msg_3"]
}

// SYNC_RESPONSE
{
  "deviceId": "DEVICE-B4E2",
  "messages": [
    {
      "id": "msg_4",
      "convId": "conv_DEVICE-7F29",
      "sender": "DEVICE-B4E2",
      "receiver": "DEVICE-7F29",
      "cipher": "...",
      "iv": "...",
      "ts": 1700000008000,
      "status": "SENT"
    }
  ]
}
```

---

## 4. State Machine Diagrams

### 4.1 Two-Way Synchronization Handshake
```
Device A                               Device B
   │                                      │
   │─── DNS-SD Discovery / TCP Connect ──►│
   │                                      │
   │─── SYNC_REQUEST (Known IDs) ────────►│
   │                                      │ (Computes B \ A)
   │◄── SYNC_RESPONSE (Missing msgs) ─────│
   │ (Persists missing into Room)         │
   │                                      │
   │◄── SYNC_REQUEST (Known IDs) ─────────│
   │ (Computes A \ B)                     │
   │─── SYNC_RESPONSE (Missing msgs) ────►│
   │                                      │ (Persists missing into Room)
   │                                      │
   ▼                                      ▼
[Convergence]                          [Convergence]
```
