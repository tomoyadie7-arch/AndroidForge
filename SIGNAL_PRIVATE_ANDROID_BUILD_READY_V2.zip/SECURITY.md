# SIGNAL // PRIVATE — Security Architecture & Threat Model

## 1. Cryptographic Primitives

All cryptographic implementations strictly rely on established standard Android / JVM primitives:

| Component | Primitive / Standard | Purpose |
|---|---|---|
| Identity Key Pair | **NIST P-256 (secp256r1) EC** | Device signature identity |
| Digital Signatures | **SHA256withECDSA** | Packet source authentication & tamper resistance |
| Key Agreement | **ECDH (Elliptic Curve Diffie-Hellman)** | Pairwise symmetric key derivation |
| Symmetric Encryption | **AES-256-GCM (`AES/GCM/NoPadding`)** | Authenticated message confidentiality |
| Tag Length | **128 bits** | Integrity authentication tag |
| Nonce / IV | **96-bit SecureRandom** | Unique per message encryption |
| Pairwise Key Derivation | **SHA-256 Hash of ECDH Secret** | 256-bit symmetric session key |
| Pairing Codes | **SecureRandom 36-bit entropy** | 10-minute temporary codes (`K7F-29Q-81M`) |

---

## 2. Threat Model & Mitigations

### 2.1 Eavesdropping on Public Wi-Fi / Open Hotspots
- **Threat**: An attacker on an unencrypted coffee shop Wi-Fi or rogue hotspot captures LAN packets using Wireshark.
- **Mitigation**: All message bodies are encrypted with **AES-256-GCM** using pairwise keys derived via ECDH. Only the intended recipient holding the corresponding private EC key can compute the secret. The ciphertext and authentication tag reveal zero information to Wi-Fi sniffers.

### 2.2 Packet Tampering & Man-in-the-Middle (MitM)
- **Threat**: An active attacker alters message text or attempts replay attacks.
- **Mitigation**: Every packet contains a digital signature (`SHA256withECDSA`) computed over the sender's private key and canonicalized packet fields (`v|type|id|from|to|ts|payload`). If any byte is modified, the signature check fails and the packet is immediately dropped.

### 2.3 Rogue Device Injection
- **Threat**: An unauthorized device connects to the same Wi-Fi and tries to inject messages into the mesh.
- **Mitigation**: Devices will **only** process messages from senders that are already persisted in the local Room database with status `TRUSTED`. Untrusted senders receive no acknowledgments and their packets are discarded.

### 2.4 Revoked Device Access
- **Threat**: A family member loses their phone, or trust is revoked by the network owner.
- **Mitigation**: When the Owner sets trust state to `REVOKED`, subsequent packets originating from that device ID are systematically rejected, and the device is excluded from sync sessions.

### 2.5 Zero Cloud Data Leakage
- **Threat**: Third-party subpoenas, cloud server breaches, or ISP data gathering.
- **Mitigation**: No telemetry, analytics, crash logs, or message histories are ever sent outside the local network. There is no cloud backend, database, or server.
